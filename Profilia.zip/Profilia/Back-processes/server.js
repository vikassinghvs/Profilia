const express = require("express");
const cors = require("cors");
const app = express();
const bodyParser = require('body-parser')

app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));
//app.use(express.json());       // to support JSON-encoded bodies
//app.use(express.urlencoded()); // to support URL-encoded bodies
app.use(cors());

var url = 'mongodb://localhost:27017/Mahindra';


app.post("/search",function(req,res){
    var email = req.body.email;
    var number = req.body.number;

    MongoClient.connect(url, function(err, db) {
  assert.equal(null, err);
  console.log("Connected correctly to server");

  db.collection("Records").find({"Email":email,"Number":number}).toArray(function(err,docs){
      res.send(docs);
  })
      db.close();

    });
  });
});
})

app.listen(8089);
