import requests
import re
import nltk
from nltk.tokenize import RegexpTokenizer
from bs4 import BeautifulSoup

tokenizer = RegexpTokenizer(r'\w+')
home_page = "https://www.quora.com"
#def profile_shortlist();
def hasNumbers(inputString):
     return any(char.isdigit() for char in inputString)

def generate_link(link):
        full_link = []
        size = len(link)
        for i in range(0,size):
                new_link = home_page+link[i]
                full_link.append(new_link)
        return full_link
def filter_(words,first_name,middle_name,last_name):
        new_words = []
        if first_name != words[1]:
                    return -1
        if middle_name == '':
                    if last_name != words[2]:
                        return -1
                    if not(hasNumbers(words[3])):
                        return -1
        else :
             if middle_name != words[2]:
                return -1
             elif last_name !=words[3]:
                return -1
        new_words.append(words)
        return 0



def crawl_search(response,keyword,first_name,middle_name,last_name,work,school,lives_in):
        profile = []
        soup = BeautifulSoup(response, 'html.parser')
        tag = soup.find_all(class_='user')
        size = len(tag)
        if size > 2:
            if work == keyword:
                if lives_in != '':
                    keyword = keyword +"%20"+ lives_in
                    print(keyword)
                    response = search2(first_name,middle_name,last_name,keyword,work,school,lives_in)

                elif school != '':

                    keyword = keyword +"%20"+ school
                    response = search2(first_name,middle_name,last_name,keyword,work,school,lives_in)
            elif school == keyword:
                keyword = keyword +"%20"+ lives_in
                response = search2(first_name,middle_name,last_name,keyword,work,school,lives_in)
            else:
                return -1
            response = search2(first_name,middle_name,last_name,keyword,work,school,lives_in)
        soup = BeautifulSoup(response, 'html.parser')
        tag = soup.find_all(class_='user')
        size = len(tag)
        for i in range (0,size):
                # for j in range(0,6):
                     new = tag[i].previous
                     links = str(new.a['href'])
                     copy = str.lower(links)
                     words= tokenizer.tokenize(copy)
                     flag = filter_(words,first_name,middle_name,last_name,)
                     if flag == -1:
                            continue
                     profile.append(links)
        full_link = generate_link(profile)
        #print(full_link)
        return full_link
        #        new = tag[i].previous
         #       new = new[i].previous
          #      print(new)
        #new = tag.previous
        #new = new.previous
        #profile = new.a['href']
        #print(profile)
        #url = "https://www.quora.com/"+profile+"/answers"
        #print(url)
        #response = requests.get(url,headers = {'User-agent': 'Chrome 0.1'})
        #soup = BeautifulSoup(response.text, 'html.parser')
        #print(soup.prettify())
        #f = open("quora1.html","w")
        #f.write(response.text)
def search2(first_name,middle_name,last_name,keyword,work,school,lives_in):
        if middle_name == "":
            url = home_page+'/search?q='+first_name+'%20'+last_name+'%20'+keyword+'&type=profile'
        else:
            url = home_page+'/search?q='+first_name+'%20'+middle_name+'%20'+last_name+'%20'+keyword+'&type=profile'
        response = requests.get(url,headers = {'User-agent': 'Chrome 0.1'})
        return(response.text)
def search(first_name,middle_name,last_name,keyword,work,school,lives_in):
        if middle_name == "":
            url = home_page+'/search?q='+first_name+'%20'+last_name+'%20'+keyword+'&type=profile'
        else:
            url = home_page+'/search?q='+first_name+'%20'+middle_name+'%20'+last_name+'%20'+keyword+'&type=profile'
        response = requests.get(url,headers = {'User-agent': 'Chrome 0.1'})
        soup = BeautifulSoup(response.text, 'html.parser')
        flag = crawl_search(response.text,keyword,first_name,middle_name,last_name,work,school,lives_in)
        if flag == -1:
            print("----------------Cannot--Find-------------------------")
        else:
            return flag;

def searchQuora(first_name,middle_name,last_name,work,school,lives_in):
    print(first_name);
    print(middle_name);
    print(last_name);
    print(work);
    print(school);
    print(lives_in);
    work =re.sub(r' ','%20',work)
    schoool = re.sub(r' ','%20',school)
    if work =='':
        if school == '':
            if lives_in == '':
                print("----------------Cannot--Find-------------------------")
            else:
                keyword = lives_in
        else:
            keyword = school
    else:
        keyword = work
    return search(first_name,middle_name,last_name,keyword,work,school,lives_in)



#searchQuora('rohan','','chougule','','army institute of technology','pune')
