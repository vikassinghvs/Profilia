from collections import deque
from multiprocessing import Process
from multiprocessing import Queue

import more_clean_up
import login
import linked
import twitter
import time
import glassdoor
import quoraExtended
import facebookFetch
import Segregate
import googleSearch

emailid = ['vikassinghvs1999@gmail.com','8006676585','vikassinghvs1997@gmail.com','anirudh.murali@wispero.com','chougule.crt@gmail.com','vikassinghvs2001@gmail.com','babamosak@yahoo.com','9759252959'];
passid = ['passpass1','suraj@123','passpass1','Chougule@359','@jayimo1997'];
import more_clean_up
#10_Sample_Records.csv
input_file = more_clean_up.lets_clean("10_Sample_Records.csv")
people,company = Segregate.readFile(input_file);
sizeOfPeople = len(people);
sizeOfCompany = len(company);

DataQueue = Queue();
compQueue = Queue();
lnQueue = Queue();
twQueue = Queue();
qoQueue = Queue();
glassDoor = Queue();
facebookLinksQueue = Queue();

for i in range(0,sizeOfCompany):
    DataQueue.put(company[i]);
    #compQueue.put(company[i]);

for i in range(0,sizeOfPeople):
    DataQueue.put(people[i])
    #compQueue.put(people[i])


def ProcessOne(DataQueue,lnQueue,twQueue,qoQueue,glassDoor,facebookLinksQueue,email,passw,compQueue):
    fb = login.FaceBook();
    ln = linked.LinkedIn();
    tw = twitter.TwitterPy();

    fb.Login(email,passw);

    fbp = Process(target = login.FaceBookStart, args = [fb,DataQueue,lnQueue,twQueue,qoQueue,facebookLinksQueue,compQueue]);
    lnp = Process(target = ln.loopFinalLinked, args = [DataQueue,lnQueue,qoQueue,glassDoor]);
    twp = Process(target = tw.loopFinalTwitter, args = [DataQueue,twQueue]);

    fbp.start();
    lnp.start();
    twp.start();

    p1.join();
    p2.join();
    p3.join();

    fb.tearDown();

time.sleep(0.5);


p1 = Process(target = ProcessOne, args = [DataQueue,lnQueue,twQueue,qoQueue,glassDoor,facebookLinksQueue,emailid[0],passid[0],compQueue]);
p2 = Process(target = ProcessOne, args = [DataQueue,lnQueue,twQueue,qoQueue,glassDoor,facebookLinksQueue,emailid[2],passid[0],compQueue]);
#p3 = Process(target = ProcessOne, args = [DataQueue,lnQueue,twQueue,qoQueue,glassDoor,facebookLinksQueue,emailid[3],passid[0]]);
#p4 = Process(target = ProcessOne, args = [DataQueue,lnQueue,twQueue,qoQueue,glassDoor,facebookLinksQueue,emailid[4],passid[3]]);
#p12 = Process(target = ProcessOne, args = [DataQueue,lnQueue,twQueue,qoQueue,glassDoor,facebookLinksQueue,emailid[7],passid[4]]);
p5 = Process(target = glassdoor.loopGlassDoor ,args = [glassDoor]);
p6 = Process(target = quoraExtended.loopQuoraExtended, args = [qoQueue]);
p7 = Process(target = facebookFetch.facebookFetch, args = [facebookLinksQueue,emailid[1],passid[1]]);
#p8 = Process(target = facebookFetch.facebookFetch, args = [facebookLinksQueue,emailid[5],passid[0]]);
#p9 = Process(target = facebookFetch.facebookFetch, args = [facebookLinksQueue,emailid[6],passid[0]]);
p10 = Process(target = googleSearch.loopGoogleSearch, args = [compQueue]);
#p11 = Process(target = googleSearch.loopGoogleSearch, args = [compQueue]);


time.sleep(2);

p1.start();
p2.start();
#p3.start();
#p4.start();
#p12.start();
p5.start();
p6.start();
p7.start();
#p8.start();
#p9.start();
p10.start();
#p11.start();

p1.join();
p2.join();
#p3.join();
#p4.join();
#p12.join();
p5.join();
p6.join();
p7.join();
#p8.join();
#p9.join();
p10.join();
#p11.join();
