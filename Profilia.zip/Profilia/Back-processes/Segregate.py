import pandas as pd
from nltk.tokenize import RegexpTokenizer
import re


tokenizer = RegexpTokenizer(r'\w+')
Company_analyser = ["PVT","LTD"]
motor_dealers = ["MOTORS","DEALERS","AUTOMOBILES","CARS","AUTOS","GARAGE","AGENCIES","AUTOLINKS","ENTERPRISES","WORKSHOP","LIMITED","TOURS","SOLUTIONS","SCHOOL","PLTD","TRAVELS"]
family = ["S/O","D/O","W/O","S.O","D.O","W.O","SON","(DIRECTOR)"]

def clean_up(input_):
    output = input_
    no_of_rows = input_.shape[0]
    company_or_not = []

    for i in range(0,no_of_rows):
        company = False
        name_ = input_.iloc[i][1].upper()
        # print name_
        words = re.findall(r"[\w/']+",name_)
        print words
        flag = 0
        for j in range(0,len(words)):
            if words[j] in motor_dealers:
                print name_
                company = True
                name = words[0:j+1]
                flag = 1
                break
            elif words[j] in Company_analyser:

                company = True

                name = words[0:j]
                flag = 1
                break
            elif words[j] in family:
                name = words[0:j]
                flag = 1
    #             father_name = words[j:]
    #             print(name)
                break
        company_or_not.append(company)
        if flag == 0:
            name = " ".join(words)
        else:
            name = " ".join(name)

    #     name = " ".join(name)
        output.iloc[i,1] = name
    output.loc[:,'company_or_not'] = pd.Series(company_or_not, index=output.index)
    people = output.loc[output["company_or_not"]==False ]
    people = people.drop("company_or_not", axis=1)
    companies = output.loc[output["company_or_not"]==True ]
    companies = companies.drop("company_or_not",axis = 1)
    people.to_csv("people.csv")
    companies.to_csv("companies.csv")

    people_array = people.as_matrix(columns=None)
    companies_array = companies.as_matrix(columns=None)
    return people_array,companies_array
# print(people)
# print(companies)

def readFile(input_):
	# input_ = pd.read_csv("clean1.csv",header = -1,dtype = str)
	#print input_.shape[1]
	people,companies = clean_up(input_)

	return people,companies;
