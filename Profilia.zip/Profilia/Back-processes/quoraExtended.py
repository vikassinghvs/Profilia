import time
import selenium
import json
import requests
from selenium import webdriver
import nltk
import re
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.tokenize import RegexpTokenizer
from bs4 import BeautifulSoup
from pymongo import MongoClient
from selenium.webdriver.chrome.options import Options

Mclient = MongoClient('localhost',27017);
db = Mclient.Mahindra;
options = Options()
options.add_argument("--disable-notifications")
driver = webdriver.Chrome("/usr/local/bin/chromedriver",chrome_options = options)

tokenizer = RegexpTokenizer(r'\w+')

bag_of_words=[
"car","scooter","scotty","tractor","bolero","jeeto","minivan","camper","maxitruck","supro",
"scorpio","tuv300","xuv500","thar","kuv100","xylo","e2o","nuvosport","verito","xuv","tuv","kuv"
"verito","yuvo","orchard","di","arjun","novo","eco","yuvraj","ambulance","di3200","gio","torro","traco","blazo","genio","maximo","truxo","loaadking"
]
def get_sentiment(text):
    r = requests.post(url_for_senti_call, data={'text':text})
    r = json.loads(r.text)
    return r['label']


def open_page(url):
        driver.get(url)
        return driver

def page_loader(driver):
    last_height = driver.execute_script("return document.body.scrollHeight")
    SCROLL_PAUSE_TIME = 3
    while True:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(SCROLL_PAUSE_TIME)
        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
              break
        last_height = new_height
    question_element = driver.find_elements_by_class_name('question_link')
    return question_element

def get_question_text(elements):
    question_list = []
    q_no = []
    size = len(elements)
    for i in range(0,size):
        question = elements[i].get_attribute("href")
        question_list.append(elements[i].get_attribute("href"))
        question_list[i] = str.lower(str(question_list[i]))
        words = tokenizer.tokenize(question_list[i])
#         print(words)
        #words_len = len(words)
        words_len = len(words)

        for k in range(0,words_len):
                if words[k] == 'mahindra':

                        for j in range(0,words_len):
                                if words[j] in bag_of_words:
#                                         print("BC")
                                        q_no.append(i)
                                        break
    #print(q_no)
    return q_no ,question_list


def extract_answers(driver,q_no):
        answer_list = []
        answer_text = []
        answer_elements = driver.find_elements_by_class_name('answer_body_preview')
        size = len(answer_elements)
#         print(size)
        for i in q_no:
            answer_list.append(answer_elements[i])
            answer_child = answer_elements[i].find_elements_by_class_name('rendered_qtext')
            answer_size = len(answer_child)
            for k in range(0,answer_size):
                answer_text.append(answer_child[k].text)
#             if answer_size == 1:
#                 print(answer_child)
#                 print("--------------------ONE-----------------")
#             else :
#                 print(answer_child.find_elements_by_class_name('rendered_qtext'))
#                 print("---------------two-------------")

        return answer_text

def getData(url):
        question_links = []
        sentiment = ''
        answer_list = []
        driver = open_page(url)
        question_element = page_loader(driver)
        q_no , question_list= get_question_text(question_element)
        for i in q_no:
                question_links.append(question_element[i].get_attribute("href"))
        if len(q_no) > 0:
            answer_list = extract_answers(driver,q_no)
            k = 0
            for i in q_no:
                sentiment = get_sentiment(answer_list[k])
                k += 1
        #driver.quit()

        output = getUserInfo(str(url)+'/topics/')
        output_1 = {
                    'description': output['description'],
                    'topics':output['topics'],
                    'credential':output['credential'],
                    'questions' : question_links,
                    'answers': answer_list,
                    'sentiment':sentiment
                     }
        return(output_1)

def getUserInfo(lrl):
    topics = []
    response = requests.get(lrl,headers = {"User-agent" : 'Chrome 0.1'})
    soup = BeautifulSoup(response.content,"lxml")

    #about what he has the knowledge about
    knowledge=soup.findAll(class_='TopicNameSpan')

    for values in knowledge:
        topics.append(values.text)


    #His Credentials and Highlights section
    credential = []
    CredentialAndHighlights = soup.findAll(class_='UserCredential')
    for values in CredentialAndHighlights:
        credential.append(values.text)

    #Ye sabme nahi milta jaise chougule me nahi h About khud se likha
    About =soup.findAll(class_='qtext_para')
    description = ''
    for values in About:
        description = values.text
    output = {
        'description' : description,
	'topics': topics,
	'credential':credential

        }
    return output
  #  f=open("lrl","w")
   # f.write(response.content)



url_for_senti_call = "http://text-processing.com/api/sentiment/"
#getData(input)


def loopQuoraExtended(qoQueue):
    print("loopQuoraExtended Called");
    while 1:
        try:
            if qoQueue.qsize() != 0:
                print("Processing Quora Link");
                record = qoQueue.get();
                print("Quora Record : ");
                print(record);
                quoraExtResult = [];
                for i in record["Link"]:
                    Result = getData(i);
                    Result["Link"] = i;
                    print(Result);
                    quoraExtResult.append(Result);
                db.Records.update({"Email":record["email"],"Number":record["number"]},{'$set':{"QuoraAnalysis":quoraExtResult}});
        except Exception as e:
            pass;
