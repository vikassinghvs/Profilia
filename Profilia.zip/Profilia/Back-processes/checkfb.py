from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import time;
from pymongo import MongoClient
Mclient = MongoClient('localhost',27017);
db = Mclient.Mahindra;
# options = webdriver.ChromeOptions()
# options.add_argument('--ignore-certificate-errors')
# options.add_argument("--test-type")
# options.binary_location = "/usr/local/bin"

def facebookFetch():
    options = Options()
    options.add_argument("--disable-notifications")
    driver = webdriver.Chrome("/usr/local/bin/chromedriver",chrome_options = options)
    driver.get("http://facebook.com");
    facebookUsername = "8006676585";
    facebookPass = "suraj@123";
    emailFieldID = "email";
    passFieldID = "pass";
    loginButtonXPath = "//input[@value = 'Log In']";
    #searchBarXPath = "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div[2]/div/form/div/div/div/div/input[2]"
    #searchBarButtonXPath = "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div[2]/div/form/button/i"
    #resultTextXPath = "/html/body/div[1]/div[3]/div[1]/div/div[3]/div[2]/div[2]/div[2]/div/div/div/div[4]/div/div/div/div[1]/div/div/div/div/div/div[2]/div"
    emailFieldElement   =   WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_id(emailFieldID))
    #print("emailFieldElement found : "+str(emailFieldElement));
    passFieldElement    =   WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_id(passFieldID))
    #print("passFieldElement found : "+str(passFieldElement));
    loginButtonElement  =   WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_xpath(loginButtonXPath));
    #print("loginButtonElement found : "+str(loginButtonElement));

    emailFieldElement.clear();
    emailFieldElement.send_keys(facebookUsername);
    passFieldElement.clear();
    passFieldElement.send_keys(facebookPass);
    loginButtonElement.click();
    print("Login : Done");

    # https://www.facebook.com/profile.php?id=100002957314156&ref=br_rs
    # https://www.facebook.com/profile.php?id=100002957314156&lst=100021937830542%3A100002989430384%3A1506272795&sk=about&section=education&pnref=about

    notReqd = ["No additional details to show","No favourite quotes to show","No schools/universities to show","No places to show","Education","Community","Actor","TV channel","Musician","Artist","Video game","App page","Games/toys","TV programme","Interest","Novel","Manga","Media","TV channel","TV series","TV network","LikeFollow","Report","Book","Join","members","Life . Comment","Like","Comment","No relationship info to show","No family members to show","No workplaces to show","No contact info to show"];

    while 1:
        #time.sleep(0.3);
        #if facebookLinksQueue.qsize() != 0:
            #record = facebookLinksQueue.get();
            fbLink = "https://www.facebook.com/profile.php?id=100004611426388&ref=br_rs";# ["Link"];
            if fbLink.find("profile") == -1:
                fbLinkSplit = fbLink.split("?");
                finalFbLink = fbLinkSplit[0] + "/about?lst=100021937830542%3A100005950025969%3A1506264524&section=";
            else:
                fbLinkSplit = fbLink.split("&");
                finalFbLink = fbLinkSplit[0] + "&lst=100021937830542%3A100002989430384%3A1506272795&sk=about&section=";
            toget = ["overview","education","living","contact-info","relationship","bio","year-overviews"]
            facebookInfo = {}
            for fetch in toget:
                try:
                    driver.get(finalFbLink+fetch+'&pnref=about')
                    parentElement = WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_xpath("/html/body/div[1]/div[3]/div[1]/div/div[2]/div[2]/div[2]/div/div[2]/div/div/div[1]/div[2]/div/ul/li[2]/div/div[2]/div"));
                    elementList = parentElement.find_elements_by_tag_name("li")
                    info = [];

                    for i in elementList:
                        if i.text not in notReqd:
                            #print("data append")
                            correctIt = (i.text).encode('utf-8').split("\n");
                            if len(correctIt) == 2:
                                finalString = correctIt[0] + " : " + correctIt[1];
                            else:
                                finalString = correctIt[0];
                            info.append(finalString);
                    if fetch == "contact-info":
                        fetch = "contact_info";
                    if fetch == "year-overviews":
                        fetch = "year_overviews";

                except Exception as e:
                    pass;
                facebookInfo[fetch] = info;


            SCROLL_PAUSE_TIME = 8;
            last_height = driver.execute_script("return document.body.scrollHeight")

            while True:
                # Scroll down to bottom
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

                # Wait to load page
                time.sleep(SCROLL_PAUSE_TIME)

                # Calculate new scroll height and compare with last scroll height
                new_height = driver.execute_script("return document.body.scrollHeight")
                if new_height == last_height:
                    break
                last_height = new_height

            fetch = ["map","sports","likes","games","events","reviews","groups","tv","books","likes"]

            for info in fetch:

                    #print("inside the loop")
                    result = [];

                    try:
                        parentElement = WebDriverWait(driver,0.7).until(lambda driver: driver.find_element_by_id("pagelet_timeline_medley_" + info));
                        childElement = parentElement.find_elements_by_tag_name("li");
                        for i in childElement:
                            #pritn("inside childElement");
                            rawData = str(i.text).split("\n");
                            for data in rawData:
                                if data not in notReqd:
                                    result.append(data);

                        print("=====================fetching Done : "+info);
                        facebookInfo[info] = result;

                    except Exception as e:
                        print(e);

                    # try:
                    #     parentElement = WebDriverWait(driver,0.2).until(lambda driver: driver.find_element_by_id("pagelet_timeline_medley_" + info));
                    #     childElement2 = parentElement.find_element_by_css_selector("a");
                    #     for i in childElement2:
                    #         #pritn("inside childElement");
                    #         rawData = str(i.text).split("\n");
                    #         for data in rawData:
                    #             if data not in notReqd:
                    #                 result.append(data);
                    #     print("=====================fetching Done : "+info);
                    #     facebookInfo[info] = result;
                    #
                    # except Exception as e:
                    #     print(e);


            #db.Records.update({"Email":record["Email"],"Number":record["Number"]},{'$set':{"facebookInfo":facebookInfo}});
            print(str(facebookInfo));
    #driver.save_screenshot("screenshot.png")


    driver.close()

facebookFetch();
