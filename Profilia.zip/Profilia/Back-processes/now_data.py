import re
import requests
from bs4 import BeautifulSoup

class LinkedInAllData:

    def __init__(self):
        self.client = requests.Session()

        HOMEPAGE_URL = 'https://www.linkedin.com'
        LOGIN_URL = 'https://www.linkedin.com/uas/login-submit'

        html = self.client.get(HOMEPAGE_URL).content
        soup = BeautifulSoup(html,"lxml")
        csrf = soup.find(id="loginCsrfParam-login")['value']

        login_information = {
            'session_key':'anirudhmurali_15090@aitpune.edu.in',
            'session_password':'dssc0802',
            'loginCsrfParam': csrf,
        }

        self.client.post(LOGIN_URL, data=login_information)

    def getData(self,profileLink):
        url_hit="https://www.linkedin.com/in/"+profileLink+"/"
        rajjo = self.client.get(url_hit)

        head_of_user_name = rajjo.content.find("&quot;headline&quot;:&quot;")
        head_of_user_name=head_of_user_name+27
        position_of_end=head_of_user_name+rajjo.content[head_of_user_name:].find('&quot')
        headline_data=rajjo.content[head_of_user_name:position_of_end]

        head_of_user_name =[m.start()+30 for m in re.finditer('&quot;companyName&quot;:&quot;', rajjo.content)]
        position_of_end=[i+rajjo.content[i:].find('&quot') for i in head_of_user_name]
        company_he_worked_for=[rajjo.content[i:j] for i,j in zip(head_of_user_name,position_of_end)]

        head_of_user_name =[m.start()+29 for m in re.finditer('&quot;schoolName&quot;:&quot;', rajjo.content)]
        position_of_end=[i+rajjo.content[i:].find('&quot') for i in head_of_user_name]
        study_details=[rajjo.content[i:j] for i,j in zip(head_of_user_name,position_of_end)]

        head_of_user_name =[m.start()+31 for m in re.finditer('&quot;locationName&quot;:&quot;', rajjo.content)]
        position_of_end=[i+rajjo.content[i:].find('&quot') for i in head_of_user_name]
        location_he_vistied=[rajjo.content[i:j] for i,j in zip(head_of_user_name,position_of_end)]

        study_details=list(set(study_details))
        location_he_vistied=list(set(location_he_vistied))

        # print headline_data
        # print location_he_vistied
        # print study_details
        # print company_he_worked_for

        return {'headline_data':headline_data,'locations':location_he_vistied,'Studies':study_details,'Companies':company_he_worked_for};


# lnt = LinkedInAllData();
#
# lnt.getData("manirudh");
