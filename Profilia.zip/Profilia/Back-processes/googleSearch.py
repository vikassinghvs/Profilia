import requests
import re
from bs4 import BeautifulSoup
from nltk.tokenize import RegexpTokenizer
from pymongo import MongoClient

Mclient = MongoClient('localhost',27017);
db = Mclient.Mahindra;

tokenizer1 = RegexpTokenizer(r'\d')
tokenizer = RegexpTokenizer(r'\w+')

def return_search(address,search_term):
        flag = 0
        states = ["Andhra Pradesh","Arunachal Pradesh ","Delhi","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Andaman and Nicobar Islands","Chandigarh","Dadra and Nagar Haveli","Daman and Diu","Lakshadweep","National Capital Territory of Delhi","Puducherry"]
        for i in range(0,len(states)):
            states[i] = str.lower(states[i])
            states[i] = re.sub(' ', '', states[i])
        # print(states)

        address = str.lower(address)
        address = address.split(',')
        for i in range(0,len(address)):
        #     print(address[i])

            words = tokenizer.tokenize(address[i])
            words = " ".join(words)

            words = re.sub(r'\d+', '', words)
            words = re.sub(' ', '', words)
        #     print(words)
            if words in states:
                flag = 1
                break
                print i
        if flag == 1:

            address[i] = re.sub(r'\d+', '', address[i])
            if len(address) > 2:
                additional_search = address[i-2:i+1]
            if len(address)== 0:
                additional_search = ''
            elif len(address) <= 2:
                additional_search = address[1:len(address)]

            for i in range(0,len(additional_search)):
                additional_search[i] = re.sub(" ","+",additional_search[i])
            additional_search = "".join(additional_search)
        else:
            additional_search = ""
        search_term = search_term+additional_search+"mouthshut"+"reviews"
        return search_term

def scrap_google(soup):
    details = {}
    website = ''
    direction = ''
    type_ = ''
    description = ''
    tag = soup.find(class_ = '_POh')
    if tag is not None:
        type_ = tag.span.text
        details.update({'Type':type_})

    tag = soup.find(class_ = '_wGh')
    if tag is not None:
        description = tag.text
        details.update({'Description':description})

    tag = soup.find(class_ = '_IGf')
    if tag is not None:
        tag = tag.findAll("a")
        direction = tag[0]['href']
        details.update({'direction' : direction})


        if len(tag) >1:
            website = tag[1]['href']
            words= tokenizer.tokenize(website)
            website_array = []
            for i in range(0,len(words)):
                if i < 3:
                    words[i] = ''
                    continue
                if words[i] != '':
                    website_array.append(words[i])
                if words[i] == 'com' :
                    for k in range(i+1,len(words)):
                        words[k]= ''

                    break

            website = 'http://'
            website = website + ".".join( website_array)
            details.update({'website':website})

        details.update({'direction' : direction})

    tag = soup.findAll(class_ = '_gF')
    if tag is not None:
        for i in range(0,len(tag)):
            span = tag[i].findAll("span")
            spanText = tokenizer.tokenize(span[0].text)
            spanText = "".join(spanText)
            details.update({spanText : span[1].text})
    tag = soup.findAll(class_="g")
    if tag is not None:
        links = []
        urlsa = []
        print(tag[3].a['href'])
        for i in range(0,len(tag)):
            link = tag[i].a['href']
        #     print(link)
            flag = 0
            urlsa = []
            if tag is None:
                break
            for j in range(0,len(link)):
                if link[j] == '=':
                    flag = 1
                    continue
                elif flag == 0:
                    continue
                elif link[j] == '&':
                    break
                elif flag == 1:
                      urlsa.append(link[j])
            urls = "".join( urlsa)
            links.append(urls)
            details.update({'digital_footprint': links})

    return details


def get_webiste(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text,'html.parser')
    return soup

def GoogleIT(search_term):
    url = 'https://www.google.co.in/search?q='+search_term#+'/Mahindra'
    soup = get_webiste(url)
    output = scrap_google(soup)
    if len(output) == 0:
        soup = get_webiste(url+'%20mahindra')
        output = scrap_google(soup)
    mouthshut = ''
    address = ''
    for key, value in output.iteritems() :# make----------------python2--------iteritems()
        if key.encode('utf-8') == 'Address:\xa0':
                if output['Address:\xa0'] is not None:

                    address = output['Address:\xa0']
#                     print(output)
    search_term =return_search(address,search_term)
    url = 'https://www.google.co.in/search?q='+search_term
    link = get_webiste(url)
    mouthshut = scrap_google(link)
#                     print(mouthshut['digital_footprint'][0])
    if mouthshut != '':
        output.update({'mouthshutLink':mouthshut['digital_footprint'][0]})


    return output


#search_term = 'the high spirits'   #The input please not the %20
headers = {'User-agent': 'Chrome 0.1'}

# output = GoogleIT("the high spirits")
# print(output)          #if output is null try adding fields
import json

def get_sentiment(text):
    r = requests.post(url_for_senti_call, data={'text':text})
    r = json.loads(r.text)
    return r['label']


def getMouthshut(lrl):
	response = requests.get(lrl)
	soup = BeautifulSoup(response.content,"lxml")

	#to find the star rating
	output = {}
	star=soup.findAll(class_='avg-star')
	for values in star:
		print(values.text)
	loc = ''
	comp = ''
	cont = ''
	#to find location
	info=soup.findAll(class_='info-div')
	if info[0] is not None:
		loc=info[0].text
		print(loc)
		# loc = loc.rstrip()
		loc = loc.replace('\n', '').replace('\r', '')
		# loc = loc.split(" ")
		#loc = " ".join(loc)
		output.update({'Location':loc})
	if info[1] is not None:
		comp=info[1].text
		comp = comp.replace('\n', '').replace('\r', '')
		output.update({'Tags':comp})
	if info[2] is not None:
		cont=info[2].text
		cont = cont.replace('\n', '').replace('\r', '')
		output.update({'Contact':cont})
	#
	# print(loc)
	# print(comp)
	# print(cont)
	review_list = []
	sentiment_list =[]
	review=soup.findAll(class_='more')
	if review is not None:
		for x in range (0,len(review)):
			review_list.append(review[x].text)
			sentiment = get_sentiment(x)
			sentiment_list.append(sentiment)
			review_list[x] = review_list[x].replace('\n', '').replace('\r', '')
		output.update({'Reviews':review_list})
		output.update({'Sentiment':sentiment_list})
	return output
#lrl = "http://www.mouthshut.com/car-dealers/Sireesh-Auto-Bangalore-reviews-925072896"

url_for_senti_call = "http://text-processing.com/api/sentiment/"
# output = getMouthshut(lrl)
# print(output)
#"MOTORS","DEALERS","AUTOMOBILES","CARS","AUTOS","GARAGE","AGENCIES","AUTOLINKS","ENTERPRISES","WORKSHOP","LIMITED","TOURS","SOLUTIONS","SCHOOL","PLTD","TRAVELS"

def loopGoogleSearch(compQueue):
    while 1:
        if compQueue.qsize() != 0:
            try:
                record = compQueue.get();
                if record[1] != "":
                    search_term = record[1];
                elif record[2] != "":
                    search_term = record[2];
                #outMouthshut = {};
                output = GoogleIT(search_term);
                #outMouthshut = getMouthshut(output["mouthshutLink"]);
                #output["mouthshut"] = outMouthshut;

                print(output);
                if db.Records.find_one({"Email":record[3],"Number":record[0]}) != None:
                    db.Records.update({"Email":record[3],"Number":record[0]},{'$set':{"GoogleData":output,"Type":"Company"}});
                else:
                    db.Records.insert({"Email":record[3],"Number":record[0],"GoogleData":output,"Type":"Company"});
            except Exception as e:
                print(e);
