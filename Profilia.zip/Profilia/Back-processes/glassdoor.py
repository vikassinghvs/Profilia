import re
import requests
from bs4 import BeautifulSoup
import json
import pandas as pd
import nltk
import re
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.tokenize import RegexpTokenizer
from pymongo import MongoClient
Mclient = MongoClient('localhost',27017);
db = Mclient.Mahindra;

tokenizer = RegexpTokenizer(r'\w+')

#import geograpy
#from geograpy import places

		# location_he_vistied=list(set(location_he_vistied))


def get_sentiment(text):
	r = requests.post(url_for_senti_call, data={'text':text})
	r = json.loads(r.text)
	return r['label']



def not_exact_hit(company_data,space_removed_new_company,company_name_split,company_position_words):

		final_compay_data={}
		hit_flag=0

		for i in range(1,len(company_name_split)+1):
			actual_company_name_passed=''.join(company_name_split[0:i])

			response = requests.get('http://api.glassdoor.com/api/api.htm?t.p=198675&t.k=bNhFK8dJnmY&userip=0.0.0.0&useragent=59.0.3071.115&format=json&v=1&action=employers&q='+actual_company_name_passed, headers=headers)
			company_data=json.loads(response.content)
			company_data=company_data["response"]["employers"]

			for single_company in company_data:
				new_company=single_company["name"]
				new_company=new_company.replace(' ','')
				if new_company.upper()==actual_company_name_passed.upper() or len(company_data)==1:
					hit_flag=1
					single_company_keys=single_company.keys()


					final_compay_data["id"]=single_company["id"]
					final_compay_data["name"]=single_company["name"]

					if 'industry' in single_company_keys:
						final_compay_data["industry"]=single_company["industry"]
					else:
						final_compay_data["industry"]=""
					if 'overallRating' in single_company_keys:
						final_compay_data["overallRating"]=single_company["overallRating"]
					else:
						final_compay_data["overallRating"]=""
					if 'ratingDescription' in single_company_keys:
						final_compay_data["ratingDescription"]=single_company["ratingDescription"]
					else:
						final_compay_data["ratingDescription"]=""
					if 'sectorName' in single_company_keys:
						final_compay_data["sectorName"]=single_company["sectorName"]
					else:
						final_compay_data["sectorName"]=""
					if 'industryName' in single_company_keys:
						final_compay_data["industryName"]=single_company["industryName"]
					else:
						final_compay_data["industryName"]=""
					if 'featuredReview' in single_company_keys:
						featuredReview_keys=single_company['featuredReview'].keys()
						#print    featuredReview_keys
						if 'attributionURL' in featuredReview_keys:
							final_compay_data["attributionURL"]=single_company['featuredReview']["attributionURL"]
						else:
							final_compay_data["attributionURL"]=""
						if 'headline' in featuredReview_keys:
							final_compay_data["headline"]=single_company['featuredReview']["headline"]
						else:
							final_compay_data["attributionURL"]=""
						if 'pros' in featuredReview_keys:
							final_compay_data["pros"]=single_company['featuredReview']["pros"]
						else:
							final_compay_data["pros"]=""
						if 'cons' in featuredReview_keys:
							final_compay_data["cons"]=single_company['featuredReview']["cons"]
						else:
							final_compay_data["cons"]=""
					break
			if hit_flag==1:break #hit_flag=0
		return final_compay_data

def exact_hit(company_data,space_removed_new_company,company_name_split,company_position_words):
		final_compay_data={}
		for single_company in company_data:
			new_company=single_company["name"]
			new_company=new_company.replace(' ','')
			if new_company.upper()==space_removed_new_company.upper() or len(company_data)==1:
				single_company_keys=single_company.keys()
				# print single_company_keys
				# print single_company["name"]
				final_compay_data["id"]=single_company["id"]
				final_compay_data["name"]=single_company["name"]

				if 'industry' in single_company_keys:
					final_compay_data["industry"]=single_company["industry"]
				else:
					final_compay_data["industry"]=""
				if 'overallRating' in single_company_keys:
					final_compay_data["overallRating"]=single_company["overallRating"]
				else:
					final_compay_data["overallRating"]=""
				if 'ratingDescription' in single_company_keys:
					final_compay_data["ratingDescription"]=single_company["ratingDescription"]
				else:
					final_compay_data["ratingDescription"]=""
				if 'sectorName' in single_company_keys:
					final_compay_data["sectorName"]=single_company["sectorName"]
				else:
					final_compay_data["sectorName"]=""
				if 'industryName' in single_company_keys:
					final_compay_data["industryName"]=single_company["industryName"]
				else:
					final_compay_data["industryName"]=""
				if 'featuredReview' in single_company_keys:
					featuredReview_keys=single_company['featuredReview'].keys()
					# print featuredReview_keys
					if 'headline' in featuredReview_keys:
						final_compay_data["headline"]=single_company['featuredReview']["headline"]
					else:
						final_compay_data["headline"]=single_company['featuredReview']["headline"]
					if 'attributionURL' in featuredReview_keys:
						final_compay_data["attributionURL"]=single_company['featuredReview']["attributionURL"]
					else:
						final_compay_data["attributionURL"]=""
					if 'pros' in featuredReview_keys:
						final_compay_data["pros"]=single_company['featuredReview']["pros"]
					else:
						final_compay_data["pros"]=""
					if 'cons' in featuredReview_keys:
						final_compay_data["cons"]=single_company['featuredReview']["cons"]
					else:
						final_compay_data["cons"]=""
				break
		return final_compay_data

def extract_features(company_data,space_removed_new_company,company_name_split,company_position_words):
		company_data=company_data["response"]["employers"]
		if len(company_data)==0:
				final_compay_data = not_exact_hit(company_data,space_removed_new_company,company_name_split,company_position_words)
		else:
		    	final_compay_data = exact_hit(company_data,space_removed_new_company,company_name_split,company_position_words)
		job_positon_with_salary_array_list = get_glassdoor_info(final_compay_data,company_data,space_removed_new_company,company_name_split,company_position_words)

		return job_positon_with_salary_array_list

def search_glassdoor(features):
		 # This is chrome, you can set whatever browser you like
		company_name=features[2]
		space_removed_new_company=company_name.replace(' ','')
		company_name_split=company_name.split()
		company_position=features[3]
		company_position_words=company_position.split()
		company_position_words=[x.lower() for x in company_position_words]

		response = requests.get('http://api.glassdoor.com/api/api.htm?t.p=198675&t.k=bNhFK8dJnmY&userip=0.0.0.0&useragent=59.0.3071.115&format=json&v=1&action=employers&q='+company_name, headers=headers)
#		print type(json.loads(response.content))
		company_data=json.loads(response.content)
		job_positon_with_salary_array_list = extract_features(company_data,space_removed_new_company,company_name_split,company_position_words)
		return job_positon_with_salary_array_list

def get_glassdoor_info(final_compay_data,company_data,space_removed_new_company,company_name_split,company_position_words):
		job_positon_with_salary_array_list=[]
		job_salary_full = {}
		if any(final_compay_data)==True:
		    first_company_postion=""
		    last_company_postion=""
		    for i in range(1,8):
		        # print i
		        url_get_company_salary="https://www.glassdoor.co.in/Salary/"+final_compay_data["name"]+"-Salaries-E"+str(final_compay_data["id"])+"_P"+str(i)+".htm"
		        # print url_get_company_salary
		        response = requests.get(url_get_company_salary, headers=headers)
		        soup = BeautifulSoup(response.content,"lxml")
		        job_position=[handle.contents for handle in soup.findAll('span','strong noMargVert')]
		        job_salary_full=[handle.text for handle in soup.findAll('div','hideDesk meanPay padTop aboveRangeBar')]
		        #print first_company_postion
		        if first_company_postion==job_position[0]:
		            break
		        first_company_postion=job_position[0]
		        print first_company_postion
		        last_company_postion=job_salary_full[0]

		        for singel_job_titel,singel_job_salary  in zip(job_position,job_salary_full):
		            singel_job_titel_split=singel_job_titel[0].split()
		            singel_job_titel_split=[x.upper() for x in singel_job_titel]
		            if set(company_position_words).isdisjoint(singel_job_titel_split) == False:
		                #print singel_job_titel[0]
		                dummy_pair={}
		                dummy_pair["job_position"]=singel_job_titel[0]
		                dummy_pair["job_salary"]=singel_job_salary
		                job_positon_with_salary_array_list.append(dummy_pair)
		                break
		else:
		    for single_company in company_data:
		        new_company=single_company["name"]
		        new_company=new_company.replace(' ','')
		        if new_company.upper()==space_removed_new_company.upper() or len(company_data)==1:
		            single_company_keys=single_company.keys()
		            # print single_company_keys
		            # print single_company["name"]
		            final_compay_data["id"]=single_company["id"]
		            final_compay_data["name"]=single_company["name"]

		            if 'industry' in single_company_keys:
		                final_compay_data["industry"]=single_company["industry"]
		            else:
		                final_compay_data["industry"]=""
		            if 'overallRating' in single_company_keys:
		                final_compay_data["overallRating"]=single_company["overallRating"]
		            else:
		                final_compay_data["overallRating"]=""
		            if 'ratingDescription' in single_company_keys:
		                final_compay_data["ratingDescription"]=single_company["ratingDescription"]
		            else:
		                final_compay_data["ratingDescription"]=""
		            if 'sectorName' in single_company_keys:
		                final_compay_data["sectorName"]=single_company["sectorName"]
		            else:
		                final_compay_data["sectorName"]=""
		            if 'industryName' in single_company_keys:
		                final_compay_data["industryName"]=single_company["industryName"]
		            else:
		                final_compay_data["industryName"]=""
		            if 'featuredReview' in single_company_keys:
		                featuredReview_keys=single_company['featuredReview'].keys()
		                # print featuredReview_keys
		                if 'headline' in featuredReview_keys:
		                    final_compay_data["headline"]=single_company['featuredReview']["headline"]
		                else:
		                    final_compay_data["headline"]=single_company['featuredReview']["headline"]
		                if 'attributionURL' in featuredReview_keys:
		                    final_compay_data["attributionURL"]=single_company['featuredReview']["attributionURL"]
		                else:
		                    final_compay_data["attributionURL"]=""
		                if 'pros' in featuredReview_keys:
		                    final_compay_data["pros"]=single_company['featuredReview']["pros"]
		                else:
		                    final_compay_data["pros"]=""
		                if 'cons' in featuredReview_keys:
		                    final_compay_data["cons"]=single_company['featuredReview']["cons"]
		                else:
		                    final_compay_data["cons"]=""
		            break


		    if any(final_compay_data)==True:
		        first_company_postion=""
		        last_company_postion=""
		        for i in range(1,8):
		            # print i
		            url_get_company_salary="https://www.glassdoor.co.in/Salary/"+final_compay_data["name"]+"-Salaries-E"+str(final_compay_data["id"])+"_P"+str(i)+".htm"
		            # print url_get_company_salary
		            response = requests.get(url_get_company_salary, headers=headers)
		            soup = BeautifulSoup(response.content,"lxml")
		            job_position=[handle.contents for handle in soup.findAll('span','strong noMargVert')]
		            job_salary_full=[handle.text for handle in soup.findAll('div','hideDesk meanPay padTop aboveRangeBar')]
		            #print first_company_postion
		            if first_company_postion==job_position[0]:
		                break
		            first_company_postion=job_position[0]
		            print first_company_postion
		            last_company_postion=job_salary_full[0]

		            for singel_job_titel,singel_job_salary  in zip(job_position,job_salary_full):
		                singel_job_titel_split=singel_job_titel[0].split()
		                singel_job_titel_split=[x.upper() for x in singel_job_titel_split]
		                if set(company_position_words).isdisjoint(singel_job_titel_split) == False:
		                    # print singel_job_titel[0]
		                    dummy_pair={}
		                    dummy_pair["job_position"]=singel_job_titel[0]
		                    dummy_pair["job_salary"]=singel_job_salary
		                    job_positon_with_salary_array_list.append(dummy_pair)
		                    break

		            # print response.status_code
		sentiment_of_the_company = ''
		if len(final_compay_data)!=0:
		    sentiment_of_the_company = get_sentiment(final_compay_data["headline"])
		print(sentiment_of_the_company)
		return job_positon_with_salary_array_list,sentiment_of_the_company
def to_send_glassdoor(features):
        company_he_worked_for = features[1]
        study_details = features[2]
        location_he_vistied = features[3]
        headline_data = features[0]
        ps = PorterStemmer()
        tokenizer = RegexpTokenizer(r'\w+')


    	features = ['','','','']
    	company_name_send_to_glassdoor=""
    	country_to_send_to_glasdoor=""
    	city_to_send_to_glasdoor=""
    	position_to_send_to_glassdor=""

    	if headline_data.find(' at ')!=-1:
    	    index_of_at=headline_data.find(' at ')
    	    if headline_data[:index_of_at].find('Student')==-1:
    	        company_name_send_to_glassdoor=headline_data[index_of_at+4:]
    	        position_to_send_to_glassdor=headline_data[:index_of_at]
    	    else:
    	        company_name_send_to_glassdoor=""
    	        position_to_send_to_glassdor=""
    	else:
    	    position_to_send_to_glassdor=headline_data
    	    if len(company_he_worked_for)!=0:
    	        company_name_send_to_glassdoor=company_he_worked_for[0]

    	country_to_send_to_glasdoor=location_he_vistied[0]
    	words_that_needs_to_be_removed=['project','ltd','pvt','private','limited','india']
    	country_list = ['india','america']
    	company_name_send_to_glassdoor = str.lower(str(company_name_send_to_glassdoor))
    	words = tokenizer.tokenize(company_name_send_to_glassdoor)
    	company_size = len(words)
    	country_to_send_to_glasdoor = str.lower(str(country_to_send_to_glasdoor))
    	company_name_send_to_glassdoor = str.lower(str(company_name_send_to_glassdoor))
    	words= tokenizer.tokenize(company_name_send_to_glassdoor)
    	for i in range(0,company_size):
    		if words[i] in words_that_needs_to_be_removed:
    			words[i] = ''
    	company_name_send_to_glassdoor =  " ".join( words )
    	words= tokenizer.tokenize(position_to_send_to_glassdor)
    	country_size = len(words)
    	for i in range(0,country_size):
    		if words[i] in country_list:
    			country_to_send_to_glasdoor =  words[i]
    			words[i] = ''
    			if city_to_send_to_glasdoor == "":
    				city_to_send_to_glasdoor = " ".join( words )
    	shit = ['amp']
    	words= tokenizer.tokenize(position_to_send_to_glassdor)
    	country_size = len(words)
    	for i in range(0,country_size):
    	    if words[i] in shit:
    	        words[i]= ''
    	position_to_send_to_glassdor = " ".join( words )

    	features[0] =country_to_send_to_glasdoor
    	features[1] =city_to_send_to_glasdoor
    	features[2] =company_name_send_to_glassdoor
    	features[3] =position_to_send_to_glassdor

    	return features

url_for_senti_call = "http://text-processing.com/api/sentiment/"

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.76 Safari/537.36'}
# input_data = ['',[],[],[]]
# input_data[0] ='Head- Business &amp;  Legal Affairs,  Senior Vice President at Viacom18 Media Private Limited '
# input_data[1] = ['Zee Entertainment Enterprises Limited', 'Viacom 18 Media Private Limited', 'Viacom 18 Media Private Limited', 'Viacom18 Media Private Limited', 'Viacom18 Media Private Limited']
# input_data[2] =['National Academy of Legal Studies and Research University', 'Government Law College']
#
# input_data[3] =['Mumbai Area, India', 'Mumbai Area, India', 'Mumbai, Maharashtra, India', 'Mumbai Area, India', 'Mumbai, Maharashtra, India']
# # features = ['','','','']
# features[0] ='india'
# features[1] = ' mumbai'
# features[2] ='Viacom 18'
# features[3] ="Senior Executive"

# features =  to_send_glassdoor(input_data)
# job_positon_with_salary_array_list,sentiment = search_glassdoor(features)
# print job_positon_with_salary_array_list
# print sentiment

def loopGlassDoor(glassDoor):
	while 1:
		try:
			if glassDoor.qsize() != 0:
				data = glassDoor.get();
				record = db.Records.find_one({"Email":data["Email"],"Number":data["Number"]});
				print("GlassDoor working for the Record : "+str(data["Number"]));
				linkedinRecord = record["linkedin"];
				if len(linkedinRecord) == 0 and record["facebook"]["work"] != "":
					input_data = ['',[],[],[]];
					input_data[0] = "";
					input_data[1] = record["facebook"]["work"];
					input_data[2] = record["facebook"]["school"];
					input_data[3] = record["facebook"]["city"];
					features =  to_send_glassdoor(input_data)
					job_positon_with_salary_array_list,sentiment = search_glassdoor(features)
					if len(job_positon_with_salary_array_list) != 0:
						db.Records.update({"Email":data["Email"],"Number":data["Number"]},{'$set':{"Glassdoor":[{"fromFacebook":job_positon_with_salary_array_list,"Sentiment":sentiment}]}});  ####------------------------Update Sentiment Here---------------------------------------
				elif len(linkedinRecord) != 0:
					gdupdate = [];
					for dt in linkedinRecord:
						input_data = ['',[],[],[]];

						input_data[0] = dt["headline_data"];
						if len(dt["Companies"]) == 0:
							input_data[1] = record["facebook"]["work"];
						else:
							input_data[1] = dt["Companies"];

						if len(dt["Studies"]) == 0:
							input_data[2] = record["facebook"]["school"];
						else:
							input_data[2] = dt["Studies"];

						if len(dt["locations"]) == 0:
							input_data[3] = record["facebook"]["city"];
						else:
							input_data[3] = dt["locations"];

						features =  to_send_glassdoor(input_data)
						job_positon_with_salary_array_list,sentiment = search_glassdoor(features)
						if len(job_positon_with_salary_array_list) != 0:
							gdupdate.append({dt["linkedInID"]:job_positon_with_salary_array_list,"Sentiment":sentiment});
					if len(gdupdate) != 0:
						db.Records.update({"Email":data["Email"],"Number":data["Number"]},{'$set':{"Glassdoor":gdupdate}});###########-------Sentiment_____
		except Exception as e:
			pass;
# url = "https://www.glassdoor.co.in/Salary/"+Company_name+"-Salaries-E"+Company_id+"_P"+page_number+".htm"
