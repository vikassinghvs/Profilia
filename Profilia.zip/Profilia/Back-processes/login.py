from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

from pyvirtualdisplay import Display
from pymongo import MongoClient
Mclient = MongoClient('localhost',27017);
db = Mclient.Mahindra;

import getSegregated
import random
import time
import unittest
import unicodedata
import csv

def get_base_character(c):
    desc = unicodedata.name(unicode(c))
    cutoff = desc.find(' WITH ')
    if cutoff != -1:
        desc = desc[:cutoff]
    return unicodedata.lookup(desc)

class FaceBook:

    def __init__(self):
        options = Options()
        options.add_argument("--disable-notifications")
        self.driver = webdriver.Chrome("/usr/local/bin/chromedriver",chrome_options = options)
        #self.driver = webdriver.Chrome();
        #display = Display(visible = 0,size=(1280,1024)).start();
        #self.driver = webdriver.Chrome()#PhantomJS(executable_path='/usr/local/bin/phantomjs',service_args=['--ignore-ssl-errors=true', '--ssl-protocol=any'])
        print("### WebDriver : Chrome ###");
        self.driver.set_window_size(1280,1024)
        #self.driver.implicitly_wait(20);
        self.driver.get("https://www.facebook.com");
        print("### Facebook Login Page Loaded ###")

    def getResult(self,searchQuery,data,DataQueue,lnQueue,twQueue,facebookLinksQueue,compQueue):
        driver = self.driver;
        resultTextXPath = "//*[@id='xt_uniq_3']"
        try:
            print("==========Result for : "+searchQuery+"==========");
            #DataQueue.get();
            resultFieldElement = WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_xpath(resultTextXPath));
        except Exception as e:
            print e;
            #print("Error : No Result Found");
            raise ValueError("Not Found By Number,Trying by Email ID");




        result = resultFieldElement.text;
        resultArray = str(result).splitlines();
        #print(resultArray);

        print("\nFacebook for "+data[2]+" : Done");

        # with open("result.csv","a") as f:
        #     writer = csv.writer(f);
        #     writer.writerow(resultArray);

        # send the array to function, get back JSON
        resultArrayDict = getSegregated.loopFunc(resultArray)
        resultArrayDict["ProfilePic"] = str(resultFieldElement.find_element_by_css_selector('img').get_attribute('src')).split("?")[0]+"?width=500&height=500";
        resultArrayDict["ProfileLink"] = str(resultFieldElement.find_element_by_css_selector('a').get_attribute('href'));
        #print(resultArrayDict);
        #

        if db.Records.find_one({"Email":data[2],"Number":data[0]}) == None:
            db.Records.insert({"Name":data[1],"Email":data[2],"Number":data[0],"facebook":resultArrayDict});
        else:
            db.Records.update({"Email":data[2],"Number":data[0]},{'$set':{"facebook":resultArrayDict}});

        RecordForComp = [data[0],resultArrayDict['work'],resultArrayDict['school'],data[2]];
        print RecordForComp;
        
        lnQueue.put(data);
        twQueue.put(data);

        facebookLinksQueue.put({"Email":data[2],"Number":data[0],"Link":resultArrayDict["ProfileLink"]});
        compQueue.put(RecordForComp)


        # kickstart the process of linkedin and twitter
        # if resultArrayDict["work"] != "":
        #     print("LinkedIn Search for : "+resultArrayDict["first_name"]);
        #     Process(target = ln.searchFor, args = [resultArrayDict["first_name"],resultArrayDict["last_name"],"anirudh_murali@ymail.com","7066918164",resultArrayDict["work"],""]).start();
        #     Process(target = tw.twitterSearch, args = [resultArrayDict["city"],resultArrayDict["work"]+resultArrayDict["school"],resultArrayDict["first_name"],resultArrayDict["last_name"]]).start();
        #
        # else:
        #     print("LinkedIn Search for : "+resultArrayDict["first_name"]);
        #     Process(target = ln.searchFor, args = [resultArrayDict["first_name"],resultArrayDict["last_name"],"anirudh_murali@ymail.com","7066918164","",resultArrayDict["school"]]).start();
        #     Process(target = tw.twitterSearch, args = [resultArrayDict["city"],resultArrayDict["school"]+resultArrayDict["work"],resultArrayDict["first_name"],resultArrayDict["last_name"]]).start();

        #p2 = Process(target = tw.searchTwitter, args = []).start();


        # print("Name : "+resultArray[0]);
        #
        # for i in range(3,len(resultArray)-1):
        #     print("Education/Company : "+resultArray[i]);
        #
        # print("Place : "+resultArray[len(resultArray) - 1]);
        # print("Profile Link : "+str(resultFieldElement.find_element_by_css_selector('a').get_attribute('href')));
        # print("Profile Pic : "+str(resultFieldElement.find_element_by_css_selector('img').get_attribute('src')));
        # picLinkLarge = str(resultFieldElement.find_element_by_css_selector('img').get_attribute('src')).split("?")[0]+"?width=500&height=500";

    def searchNavigation(self,searchQuery):
        driver = self.driver;
        unicodeSearchQuery = " ";
        #driver.execute_script("window.open('');")

        for c in searchQuery:
            unicodeSearchQuery+=get_base_character(c);

        driver.get("https://www.facebook.com/search/top/?q="+unicodeSearchQuery);
        print("Navigation : Done");

    def Login(self,email,passw):
        driver = self.driver;
        facebookUsername = email;
        facebookPass = passw;
        emailFieldID = "email";
        passFieldID = "pass";
        loginButtonXPath = "//input[@value = 'Log In']";
        #searchBarXPath = "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div[2]/div/form/div/div/div/div/input[2]"
        #searchBarButtonXPath = "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div[2]/div/form/button/i"
        #resultTextXPath = "/html/body/div[1]/div[3]/div[1]/div/div[3]/div[2]/div[2]/div[2]/div/div/div/div[4]/div/div/div/div[1]/div/div/div/div/div/div[2]/div"
        try:
            emailFieldElement   =   WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_id(emailFieldID))
            #print("emailFieldElement found : "+str(emailFieldElement));
            passFieldElement    =   WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_id(passFieldID))
            #print("passFieldElement found : "+str(passFieldElement));
            loginButtonElement  =   WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_xpath(loginButtonXPath));
            #print("loginButtonElement found : "+str(loginButtonElement));

            emailFieldElement.clear();
            emailFieldElement.send_keys(facebookUsername);
            time.sleep(1);
            passFieldElement.clear();
            passFieldElement.send_keys(facebookPass);
            loginButtonElement.click();
            print("Login : Done");

        except Exception as e:
            print e;
            print("Error : Error While Trying to Log in, Try Again");

    def tearDown(self):
        self.driver.quit();


##===============================================================================================================================================================================



def FaceBookStart(fb,DataQueue,lnQueue,twQueue,qoQueue,facebookLinksQueue,compQueue):

    print("FaceBookStart Started");
    while DataQueue.qsize() != 0:
        data = DataQueue.get();
        #DataQueue.append(data);
        time.sleep(random.uniform(1,2));
        try:
            print("--------------------------------------------------------------------------------------------------------")
            #print("#### Processing for Name : "+str(data[0])+" || Number : "+str(data[1])+" ####");
            fb.searchNavigation(" +"+str(data[0])); #searchquery
            fb.getResult(str(data[0]),data,DataQueue,lnQueue,twQueue,facebookLinksQueue,compQueue);
        except ValueError as e:
            print(e);
            #print("#### Processing with Email ID : "+str(data[2])+" ####");
            try:
                fb.searchNavigation(" "+str(data[2])); #searchquery
                fb.getResult(str(data[2]),data,DataQueue,lnQueue,twQueue,facebookLinksQueue,compQueue);
            except Exception as f:
                print("Error : Searching was Unsuccessful");
        except Exception as e:
            print e;

# pool = ThreadPool(4)
#
# pool.map(testMultiTry, emailloader.dataset)

# FaceBookStart();

# ln = linked.LinkedIn();
# tw = twitter.TwitterPy();
# p2 = Process(target = ln.loopFinalLinked);
# p3 = Process(target = tw.loopFinalTwitter);
#p4 = Process(target = qb.)
#
# p1.start();
# p2.start();
# p3.start();
#
# p1.join();
# p2.join();
# p3.join();

# fb.tearDown();

    #db.myoriginal.aggregate([ { $match: {} }, { $out: "mycopy" } ])
