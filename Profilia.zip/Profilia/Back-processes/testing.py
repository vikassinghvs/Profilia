from multiprocessing.dummy import Pool as ThreadPool
import time


def func(url):
    print("func");
    time.sleep(10);

def fun2(url):
    print("fun2");
# Make the Pool of workers
pool = ThreadPool(4)
pool2 = ThreadPool(4)
# Open the urls in their own threads
# and return the results
results = pool.map(func, [""]);
fun2("");
#close the pool and wait for the work to finish
pool.close()
pool.join()
