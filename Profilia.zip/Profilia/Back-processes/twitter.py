import tweepy
import csv
from pymongo import MongoClient
import time




class TwitterPy:



    def __init__(self):
        consumer_key="JVJZjJ6SF44FLzu0GWhmhUEF3"
        consumer_secret="iWUvs36DuFVdeIqIpDMLhf3bJNWiKsarnDrdyOGH3b0cDQkK2W"
        access_token="780542960-FvJrWtAQEaBkR2scbv1Is1wLltPadNbNGvs9DdHI"
        access_token_secret="xTOPO6OZEzIptUKyOGvaIaKYfn2VBxHQUrWzluCgkgsHy"

        auth = tweepy.OAuthHandler(consumer_key,consumer_secret)
        auth.set_access_token(access_token,access_token_secret)
        self.api = tweepy.API(auth)

        MDclient = MongoClient('localhost',27017);
        self.db = MDclient.Mahindra;


    def twitterSearch(self,location,description,firstName,lastName):

        twitter_content=[]
        twitter_profile=[]

        location=location.upper();
        description=description.upper();
        first_name=firstName;
        last_name=lastName;


        location_words_data=location.split()
        description_words_data=description.split()

        perfect_hit_profile_list=[]
        hit_with_location_profile_listen_list=[]

        perfect_hit_dict={}
        hit_with_location_profile_listen_dict={}
        perfect_hit_bool_value=0
        count_of_location_match_people=0

        first_match_person=""
        last_match_person=""

        for i in range(1,50):
            user_name=self.api.search_users(q=first_name+" "+last_name,per_page=20,page=i)
            twitter_content=user_name
            if twitter_content != None:
                if  first_match_person == twitter_content[0].screen_name and last_match_person == twitter_content[len(twitter_content)-1].screen_name:
                    break
                first_match_person=twitter_content[0].screen_name
                last_match_person=twitter_content[len(twitter_content)-1].screen_name
                for single_person in twitter_content:
                    for x in location_words_data:
                             single_person.location=single_person.location.upper()
                             if single_person.location.find(x)!=-1:
                                hit_with_location_profile_listen_dict={}
                                hit_with_location_profile_listen_dict["description"]=single_person.description
                                hit_with_location_profile_listen_dict["location"]=single_person.location
                                hit_with_location_profile_listen_dict["screen_name"]=single_person.screen_name
                                hit_with_location_profile_listen_dict["profile_picture_url"]=single_person.profile_image_url
                                hit_with_location_profile_listen_list.append(hit_with_location_profile_listen_dict)
                                count_of_location_match_people=count_of_location_match_people+1
                                for w in description_words_data:
                                    single_person.description=single_person.description.upper()
                                    if single_person.description.find(w)!=-1:
                                        perfect_hit_dict={}
                                        perfect_hit_dict["description"]=single_person.description
                                        perfect_hit_dict["location"]=single_person.location
                                        perfect_hit_dict["screen_name"]=single_person.screen_name
                                        perfect_hit_dict["profile_picture_url"]=single_person.profile_image_url
                                        perfect_hit_profile_list.append(perfect_hit_dict)
                                        perfect_hit_bool_value=1
                                        break
                                break
                if perfect_hit_bool_value==1 or count_of_location_match_people==3:
                    break



        total_hit =perfect_hit_profile_list+hit_with_location_profile_listen_list
        total_hit = [dict(t) for t in set([tuple(d.items()) for d in total_hit ])]

        # keys = total_hit[0].keys();
        # with open("twitter.csv","a") as f:
        #     dict_writer = csv.DictWriter(f, keys)
        #     dict_writer.writerows(total_hit)

        #print total_hit;
        return total_hit;

    def loopFinalTwitter(self,DataQueue,twQueue):
        print("Twitter Loop Started");
        flag = 0;
        while 1:
                time.sleep(0.2);
            # print("Twitter size : "+str(twQueue.qsize()));
                try:
                    if flag == 1 and twQueue.qsize() == 0:
                        print("Twitter Loop Stopped");
                        return;
                    elif flag == 1 and twQueue.qsize() != 0:
                        flag = 0;

                    if twQueue.qsize() != 0 and flag == 0:
                        data = twQueue.get();
                        print("Twitter Data : "+str(data));
                        dbdata = self.db.Records.find_one({"Number":data[0]});
                        twitterArray  = self.twitterSearch(dbdata["facebook"]["city"],dbdata["facebook"]["work"]+" "+dbdata["facebook"]["school"],dbdata["facebook"]["first_name"],dbdata["facebook"]["last_name"])
                        self.db.Records.update({"Number":data[0]},{'$set':{"twitter":twitterArray}})

                # elif twQueue.qsize() == 0 and flag == 0:
                #     time.sleep(40);
                #     flag = 1;
                except Exception as e:
                    print("Ignore : " + str(e));

# tw = TwitterPy();
# tw.twitterSearch("Pune","","Swastik","Shrivastava")
