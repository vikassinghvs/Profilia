from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import time;
from pymongo import MongoClient
Mclient = MongoClient('localhost',27017);
db = Mclient.Mahindra;
# options = webdriver.ChromeOptions()
# options.add_argument('--ignore-certificate-errors')
# options.add_argument("--test-type")
# options.binary_location = "/usr/local/bin"


options = Options()
options.add_argument("--disable-notifications")
driver = webdriver.Chrome("/usr/local/bin/chromedriver",chrome_options = options)
driver.get("http://facebook.com");
facebookUsername = "chachagrey9@gmail.com";
facebookPass = "9410900074";
emailFieldID = "email";
passFieldID = "pass";
loginButtonXPath = "//input[@value = 'Log In']";
#searchBarXPath = "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div[2]/div/form/div/div/div/div/input[2]"
#searchBarButtonXPath = "/html/body/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div[2]/div/form/button/i"
#resultTextXPath = "/html/body/div[1]/div[3]/div[1]/div/div[3]/div[2]/div[2]/div[2]/div/div/div/div[4]/div/div/div/div[1]/div/div/div/div/div/div[2]/div"
emailFieldElement   =   WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_id(emailFieldID))
#print("emailFieldElement found : "+str(emailFieldElement));
passFieldElement    =   WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_id(passFieldID))
#print("passFieldElement found : "+str(passFieldElement));
loginButtonElement  =   WebDriverWait(driver,10).until(lambda driver: driver.find_element_by_xpath(loginButtonXPath));
#print("loginButtonElement found : "+str(loginButtonElement));

emailFieldElement.clear();
emailFieldElement.send_keys(facebookUsername);
passFieldElement.clear();
passFieldElement.send_keys(facebookPass);
loginButtonElement.click();
print("Login : Done");

driver.get("https://www.facebook.com/shailja.thakur.18/about?lst=100021937830542%3A100002135359325%3A1506277795&section=education&pnref=about")
SCROLL_PAUSE_TIME = 3

# Get scroll height
last_height = driver.execute_script("return document.body.scrollHeight")

while True:
    # Scroll down to bottom
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    # Wait to load page
    time.sleep(SCROLL_PAUSE_TIME)

    # Calculate new scroll height and compare with last scroll height
    new_height = driver.execute_script("return document.body.scrollHeight")
    if new_height == last_height:
        break
    last_height = new_height

fetch = ["map","sports","likes","games","events","reviews","groups","tv","books","likes"]

for info in fetch:
    try:
        parentElement = driver.find_element_by_id("pagelet_timeline_medley_" + info);
        childElement = parentElement.find_elements_by_tag_name("li");

        print("=====================fetching Done : "+info);

        for i in childElement:
            print(i.text);

    except Exception as e:
        pass;
driver.close();
