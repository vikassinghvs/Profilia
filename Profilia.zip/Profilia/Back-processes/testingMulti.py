from multiprocessing import Process
import sys

from multiprocessing.dummy import Pool as ThreadPool

urls = [
  'http://www.python.org',
  'http://www.python.org/about/',
  'http://www.onlamp.com/pub/a/python/2003/04/17/metaclasses.html',
  'http://www.python.org/doc/',
  'http://www.python.org/download/',
  'http://www.python.org/getit/',
  'http://www.python.org/community/',
  'https://wiki.python.org/moin/',
  'http://planet.python.org/',
  'https://wiki.python.org/moin/LocalUserGroups',
  'http://www.python.org/psf/',
  'http://docs.python.org/devguide/',
  'http://www.python.org/community/awards/'
  # etc..
  ]

pool = ThreadPool(4)


rocket = 0
iteration1 = 0;
iteration2 = 0;
iteration3 = 0;
iteration4 = 0;




def func3(self):
    global iteration3;
    iteration3 +=1
    #print(iteration);
    global rocket
    print 'start func3'
    while rocket < 10000000:
        rocket += 1
    print 'end func3'
    #print("iteration 3 : "+str(iteration3))

def func4(self):
    global rocket
    global iteration4;
    iteration4 +=1
    #print(iteration);

    print 'start func4'
    while rocket < 100000000:
        rocket += 1
    print 'end func4'
    #print("iteration 4 : "+str(iteration4))


def func1(self):
    global iteration1;
    iteration1 +=1
    global rocket

    print 'start func1'

    while rocket < 100000000:
        rocket += 1
    print 'end func1'
    #print("iteration 1 : "+str(iteration1))

def func2(self):
    global rocket
    global iteration2;
    iteration2 +=1
    #print(iteration);
    print 'start func2'
    while rocket < 100000000:
        rocket += 1
    print 'end func2'
    #print("iteration 2 : "+str(iteration2))




for i in range(0,100000000):
    print("")

p1 = Process(target = func1)
p1.start()
p2 = Process(target = func2)
p2.start()
 # #
 #    #  p1.start();
 #    #  p2.start();
 #    tt = testMulti();
 #    #
 #    # pool.map(tt.func1, urls)
 #    # print("iteration 1 : "+str(iteration1))
 #    # print("iteration 2 : "+str(iteration2))
 #    # print("iteration 4 : "+str(iteration4))
 #    # print("iteration 3 : "+str(iteration3))
 #
 #    for i in range(0,10):
 #        tt.func1();
