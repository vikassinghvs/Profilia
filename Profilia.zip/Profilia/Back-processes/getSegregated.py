import pandas as pd
import nltk
import re
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.tokenize import RegexpTokenizer
ps = PorterStemmer()
tokenizer = RegexpTokenizer(r'\w+')

from nltk.tokenize.punkt import PunktSentenceTokenizer, PunktLanguageVars
class CommaPoint(PunktLanguageVars):
    sent_end_chars = (',')

work = ["Accountant",
"Actuary",
"Advertising Managers ",
"Promotions Managers",
"Advertising Sales Agent",
"Aircraft Mechanic",
"Airline Pilot",
"Airport Security Screener",
"Airline Reservations Agent",
"Air Traffic Controller",
"Architect",
"Auto Mechanic",
"Bank Teller",
"Bartender",
"Biological Technician",
"Biomedical Engineer",
"Bookkeeping , Accounting and Auditing Clerks",
"Brick Mason",
"Budget Analyst",
"Cardiovascular Technologist",
"Cashier",
"Chef",
"Chief Executive Officer ",
"Chief Technical Officer ",
"Chief Financial Officer",
"CEO",
"CFO",
"CTO",
"Founder",
"Cofounder",
"Co-Founder",
"Chemical Technician",
"Childcare Worker",
"Chiropractor",
"Claims Adjuster, Appraiser, Examiner, and Investigator",
"Compensation and Benefits Manager",
"Computer Programmer",
"Computer Systems Analyst",
"Construction Laborer",
"Consultant",
"Cook",
"Correctional Officer",
"Court Reporter",
"Curator",
"Customer Service Representative",
"Database Administrator",
"Dental Hygienist",
"Dentist",
"Derrick Operator",
"Diagnostic Medical Sonographer",
"Director",
"Dietitian/Nutritionist",
"Doctor",
"Editor",
"Electrician",
"EMTs and Paramedics",
"English as a Second Language (ESL) Teacher",
"Epidemiologist",
"Event/Meeting Planner",
"Fashion Designer",
"Financial Advisor",
"Financial Manager",
"Financial Services Sales",
"Firefighter",
"Fitness Trainer",
"Flight Attendant",
"Funeral Director",
"Fundraiser",
"Judge",
"Glazier",
"Grant Writer",
"Graphic Designer",
"Guidance Counselor",
"Hairdressers, Hairstylists, and Cosmetologists",
"Health Educator",
"Human Resources Assistant",
"Human Resources Manager",
"Home Health Aide",
"Housekeeper",
"Industrial Designer",
"Industrial Production Manager",
"Insurance Underwriter",
"Interior Designer",
"Interpreter and Translator",
"Janitor",
"Lawyer",
"Librarian",
"Library Assistant/Technician",
"Licensed Practical Nurse",
"Loan Officer",
"Lodging Manager",
"Manicurist",
"Manufacturing Sales Representative",
"Market Research Analyst",
"Marriage and Family Therapist",
"Massage Therapist",
"Mechanical Engineer",
"Medical Assistant",
"Medical Laboratory Technician",
"Model",
"Nurse Practitioner",
"Nursing Assistant",
"Occupational Therapist",
"Occupational Therapy Assistant",
"Painter",
"Paralegal and Legal Assistant",
"Personal Trainer",
"Pharmacist",
"Pharmacy Technician",
"Physician Assistant",
"Photographer",
"Physical Therapist",
"Physical Therapy Assistant",
"Plumber",
"Police Officer",
"Postal Service Worker",
"Producer",
"Psychiatric Aide",
"Public Relations Specialist",
"Purchasing Manager",
"Receptionist",
"Registered Nurse",
"Retail Salesperson",
"Retail Supervisor",
"Roofer",
"Secretary / Administrative Assistant",
"Security Guard",
"Social Media Manager",
"SocialTO",
"Chemical Technician",
"Childcare Worker",
"Chiropractor",
"Claims Adjuster, Appraiser, Examiner, and Investigator",
"Compensation and Benefits Manager",
"Computer Programmer",
"Computer Systems Analyst",
"Construction Laborer",
"Consultant",
"Cook",
"Correctional Officer",
"Court Reporter",
"Curator",
"Customer Service Representative",
"Database Administrator",
"Dental Hygienist",
"Dentist",
"Derrick Operator",
"Diagnostic Medical Sonographer",
"Director",
"Dietitian/Nutritionist",
"Doctor",
"Editor",
"Electrician",
"EMTs and Paramedics",
"English as a Second Language (ESL) Teacher",
"Epidemiologist",
"Event/Meeting Planner",
"Fashion Designer",
"Financial Advisor",
"Financial Manager",
"Financial Services Sales",
"Firefighter",
"Fitness Trainer",
"Flight Attendant",
"Funeral Director",
"Fundraiser",
"Judge",
"Glazier",
"Grant Writer",
"Graphic Designer",
"Guidance Counselor",
"Hairdressers, Hairstylists, and Cosmetologists",
"Health Educator",
"Human Resources Assistant",
"Human Resources Manager",
"Home Health Aide",
"Housekeeper",
"Industrial Designer",
"Industrial Production Manager",
"Insurance Underwriter",
"Interior Designer",
"Interpreter and Translator",
"Janitor",
"Lawyer",
"Librarian",
"Library Assistant/Technician",
"Licensed Practical Nurse",
"Loan Officer",
"Lodging Manager",
"Manicurist",
"Manufacturing Sales Representative",
"Market Research Analyst",
"Marriage and Family Therapist",
"Massage Therapist",
"Mechanical Engineer",
"Medical Assistant",
"Medical Laboratory Technician",
"Model",
"Nurse Practitioner",
"Nursing Assistant",
"Occupational Therapist",
"Occupational Therapy Assistant",
"Painter",
"Paralegal and Legal Assistant",
"Personal Trainer",
"Pharmacist",
"Pharmacy Technician",
"Physician Assistant",
"Photographer",
"Physical Therapist",
"Physical Therapy Assistant",
"Plumber",
"Police Officer",
"Postal Service Worker",
"Producer",
"Psychiatric Aide",
"Public Relations Specialist",
"Purchasing Manager",
"Receptionist",
"Registered Nurse",
"Retail Salesperson",
"Retail Supervisor",
"Roofer",
"Secretary / Administrative Assistant",
"Security Guard",
"Social Media Manager",
"Social Worker",
"Software Developer",
"Special Education Teacher",
"Subway Operator",
"Taxi Driver",
"Teacher",
"Teacher Assistant",
"Technical Writer",
"Training and Development Manager",
"Veterinarian",
"Waiter/Waitress",
"Web Developer",
"Writer"]



def populate(i,stalker,train):
    punctuator = PunktSentenceTokenizer(lang_vars = CommaPoint())
    n_w=punctuator.tokenize(train[0][i])
    sentance = n_w[0]

    words= tokenizer.tokenize(sentance)
    if stalker["first_name"] == "":
        stalker["first_name"] = words[0]
        if len(words)==1:
            return stalker
        if len(words) == 2:
               stalker["last_name"]= words[1]

        else:
                stalker["middle_name"] = words[1]
                stalker["last_name"] = words[2]
        return stalker


    pos = nltk.pos_tag(words)
    df1 = pd.DataFrame(pos)
    #print(df1)
    size = df1.shape[0]
    for i in range(0,size):
            if df1.iloc[i][1] == 'IN':
                i = i
                #print(i)
                break

    info = df1.iloc[i + 1:size][0]
    role = df1.iloc[0:i][0]
    role = " ".join( role )
    info = " ".join( info )
    stem = ps.stem(role)
    #print(stem)
    #print(role)
    #print(info)
    if stem == "studi":
        #print("studying at :"+ info)
        info = re.sub(r'\d+', '', info)
        stalker["school"] = info
    elif stem == "student":
        info = re.sub(r'\d+', '', info)
        stalker["school"] = info
    elif stem == "live":
        #print("lives in :"+ info)
        stalker["city"] = info
    else:
        for occ in work:
            if role in occ:
                #print("working at :"+ info)
                stalker["work"] = info
                stalker["position"]= role
               # print(ps.stem(role))
    return stalker

def loopFunc(trainer):

    train = pd.DataFrame(trainer)

    stalker ={
                "first_name":"",
                "middle_name":"",
                "last_name":"",
                "work": "",
                "position":"",
                "school": "",
                "city": ""
                   }

    for i in range(0 ,train.shape[0]):
        stalker = populate(i,stalker,train)
    return stalker;
