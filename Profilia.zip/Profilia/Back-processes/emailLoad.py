import csv

class EmailLoader:
    filename = "dataset.csv"
    dataset = [];
    numbers = [];

    def __init__(self):
        with open(self.filename,"rb") as file:
            csv_reader = csv.reader(file);
            for email in csv_reader:
                self.dataset.append(email);


            #print(self.dataset);
            # for i in self.dataset:
            #     print("========================================================")
            #     print("Name     : "+str(i[0]));
            #     print("Number   : "+str(i[1]));
            #     print("Email    : "+str(i[2]));
            if(len(self.dataset) < 1):
                print("No dataset in the Given File");
            else:
                print("Loaded "+str(len(self.dataset)));
