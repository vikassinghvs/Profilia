import time
import selenium
import json
import requests
from selenium import webdriver
import nltk
import re
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.tokenize import RegexpTokenizer
tokenizer = RegexpTokenizer(r'\w+')

bag_of_words=[
"car","scooter","scotty","tractor","bolero","jeeto","minivan","camper","maxitruck","supro",
"scorpio","tuv300","xuv500","thar","kuv100","xylo","e2o","nuvosport","verito","xuv","tuv","kuv"
"verito","yuvo","orchard","di","arjun","novo","eco","yuvraj","ambulance","di3200","gio","torro","traco","blazo","genio","maximo","truxo","loaadking"
]
def get_sentiment(text):
    r = requests.post(url_for_senti_call, data={'text':text})
    r = json.loads(r.text)
    return r['label']


def open_page(url):
        driver=webdriver.Chrome()
        driver.get(url)
        return driver

def page_loader(driver):
    last_height = driver.execute_script("return document.body.scrollHeight")
    SCROLL_PAUSE_TIME = 3
    while True:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(SCROLL_PAUSE_TIME)
        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
              break
        last_height = new_height
    question_element = driver.find_elements_by_class_name('question_link')
    return question_element

def get_question_text(elements):
    question_list = []
    q_no = []
    size = len(elements)
    for i in range(0,size):
        question = elements[i].get_attribute("href")
        question_list.append(elements[i].get_attribute("href"))
        question_list[i] = str.lower(str(question_list[i]))
        words = tokenizer.tokenize(question_list[i])
#         print(words)
        #words_len = len(words)
        words_len = len(words)

        for k in range(0,words_len):
                if words[k] == 'mahindra':

                        for j in range(0,words_len):
                                if words[j] in bag_of_words:
#                                         print("BC")
                                        q_no.append(i)
                                        break
    print(q_no)
    return q_no ,question_list


def extract_answers(driver,q_no):
        answer_list = []
        answer_text = []
        answer_elements = driver.find_elements_by_class_name('answer_body_preview')
        size = len(answer_elements)
#         print(size)
        for i in q_no:
            answer_list.append(answer_elements[i])
            answer_child = answer_elements[i].find_elements_by_class_name('rendered_qtext')
            answer_size = len(answer_child)
            for k in range(0,answer_size):
                answer_text.append(answer_child[k].text)
#             if answer_size == 1:
#                 print(answer_child)
#                 print("--------------------ONE-----------------")
#             else :
#                 print(answer_child.find_elements_by_class_name('rendered_qtext'))
#                 print("---------------two-------------")

        return answer_text

def run_this_shit(url):
        question_links = []
        driver = open_page(url)
        question_element = page_loader(driver)
        q_no , question_list= get_question_text(question_element)
        for i in q_no:
                question_links.append(question_element[i].get_attribute("href"))

        answer_list = extract_answers(driver,q_no)
        k = 0
        for i in q_no:
            print(question_list[i])
            print(answer_list[k])
            sentiment = get_sentiment(answer_list[k])
            print(sentiment)
            k += 1
        driver.quit()
url_for_senti_call = "http://text-processing.com/api/sentiment/"
run_this_shit("https://www.quora.com/profile/Nakul-Khairnar")
