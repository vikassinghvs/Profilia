import re
import requests
import csv
from bs4 import BeautifulSoup
from now_data import LinkedInAllData
import time
import quora
from pymongo import MongoClient



class LinkedIn:

    linked_in_content_link=[]
    occupation_in_content_data=[]

    def __init__(self):
        mclient = MongoClient('localhost',27017);
        self.db = mclient.Mahindra;

        self.client = requests.Session()

        HOMEPAGE_URL = 'https://www.linkedin.com'
        LOGIN_URL = 'https://www.linkedin.com/uas/login-submit'

        html = self.client.get(HOMEPAGE_URL).content
        soup = BeautifulSoup(html,"lxml")
        csrf = soup.find(id="loginCsrfParam-login")['value']

        login_information = {
            'session_key':'anirudhmurali_15090@aitpune.edu.in',
            'session_password':'dssc0802',
            'loginCsrfParam': csrf,
        }

        self.client.post(LOGIN_URL, data=login_information)
        self.lnt = LinkedInAllData();


    def searchFor(self,firstName,lastName,company="",school=""):
        for i in range(1,4):
            url_hit="https://www.linkedin.com/search/results/people/?keywords="+firstName+"%20"+lastName+"&firstName="+firstName+"&lastName="+lastName+"&school="+school+"&company="+company+"&page="+str(i)
            rajjo = self.client.get(url_hit)
            index_of_user_name =[m.start()+29 for m in re.finditer('publicIdentifier', rajjo.content)]
            occupation_of_user_name =[m.start()+29 for m in re.finditer('&quot;occupation&quot;:&quot;', rajjo.content)]
            if len(index_of_user_name) == 0 : break
            position_of_end=[i+rajjo.content[i:].find('&') for i in index_of_user_name]
            occupation_position_of_end=[i+rajjo.content[i:].find('&') for i in occupation_of_user_name]
            linked_in_occupation=[rajjo.content[i:j] for i,j in zip(occupation_of_user_name,occupation_position_of_end)]
            linked_in_handle=[rajjo.content[i:j] for i,j in zip(index_of_user_name,position_of_end)]
            linked_in_handle=linked_in_handle[1:]
            linked_in_occupation=linked_in_occupation[1:]
            #print(linked_in_occupation);
            #print(linked_in_handle);

            for occ in linked_in_occupation:
                if occ not in self.occupation_in_content_data:
                    self.occupation_in_content_data.append(occ);

            for han in linked_in_handle:
                if han not in self.linked_in_content_link:
                    self.linked_in_content_link.append(han);

        allResultArray = []

        # with open("linkedInResult.csv","a") as f:
        #     for i in range(0,len(list(self.linked_in_content_link))):
        #         print (str(i+1)+" : "+str(list(self.linked_in_content_link)[i])+"      || Occupation : "+str(list(self.occupation_in_content_data)[i]))
        #         resultRow = [email,number,(self.linked_in_content_link)[i],(self.occupation_in_content_data)[i]];
        #         writer = csv.writer(f);
        #         writer.writerow(resultRow);

        for i in range(0,len(list(self.linked_in_content_link))):
            linkedInID = str(list(self.linked_in_content_link)[i]);
            # print (str(i+1)+" : "+linkedInID+"      || Occupation : "+str(list(self.occupation_in_content_data)[i]))
            # resultRow = [email,number,(self.linked_in_content_link)[i],(self.occupation_in_content_data)[i]];
            arrr = self.lnt.getData(linkedInID);
            arrr["linkedInID"] = linkedInID;
            allResultArray.append(arrr);

        self.linked_in_content_link=[]
        self.occupation_in_content_data=[]

        #print allResultArray;
        return allResultArray;

    def loopFinalLinked(self,DataQueue,lnQueue,qoQueue,glassDoor):
        print("LinkedIn Loop Started")
        flag = 0;
        while 1:
            time.sleep(1);
                # print("Linked in Size : "+str(lnQueue.qsize()));
            try:
                if flag == 1 and lnQueue.qsize() == 0:
                    print("LinkedIn Loop Stopped");
                    return;
                elif flag == 1 and lnQueue.qsize() != 0:
                    flag = 0;

                if lnQueue.qsize() != 0 and flag == 0:
                    data = lnQueue.get();
                    print("LinkedIn Data : "+str(data));
                    dbdata = self.db.Records.find_one({"Number":data[0]})

                    first_name = str.lower(str(dbdata["facebook"]["first_name"]));
                    middle_name = str.lower(str(dbdata["facebook"]["middle_name"]));
                    last_name = str.lower(str(dbdata["facebook"]["last_name"]));
                    work = str.lower(str(dbdata["facebook"]["work"]));
                    studies = str.lower(str(dbdata["facebook"]["school"]));
                    locations = str.lower(str(dbdata["facebook"]["city"]));

                    if dbdata["facebook"]["work"] != "":

                        dataFromLinked = self.searchFor(first_name,last_name,work,"");
                        Quora = [];

                        if len(dataFromLinked) == 0:
                            arrayFromQuora = quora.searchQuora(first_name,middle_name,last_name,work,studies,locations);
                            if len(arrayFromQuora) != 0:
                                for i in arrayFromQuora:
                                    Quora.append(i);

                        else:
                            for dt in dataFromLinked:
                                if len(dt["Companies"]) == 0:
                                    work = str.lower(str(dbdata["facebook"]["work"]));
                                else:
                                    work = str.lower(str(dt["Companies"][0]));

                                if len(dt["Studies"]) == 0:
                                    studies = str.lower(str(dbdata["facebook"]["school"]));
                                else:
                                    studies = str.lower(str(dt["Studies"][0]));

                                if len(dt["locations"]) == 0:
                                    locations = str.lower(str(dbdata["facebook"]["city"]));
                                else:
                                    locations = str.lower(str(dt["locations"][0]).split(",")[0]);

                                arrayFromQuora = quora.searchQuora(first_name,middle_name,last_name,work,studies,locations);
                                #arrayFromQuora.append(dt["linkedInID"]);
                                print(arrayFromQuora);
                                if len(arrayFromQuora) != 0:
                                    for i in arrayFromQuora:
                                        Quora.append(i);

                        self.db.Records.update({"Number":data[0]},{'$set':{"linkedin":dataFromLinked,"Quora":Quora}});
                        glassDoor.put({"Email":data[2],"Number":data[0]});
                        if len(Quora) != 0:
                            addToQueue = {"email":data[2],"number":data[0],"Link":Quora};
                            qoQueue.put(addToQueue);


                    elif dbdata["facebook"]["school"] != "" and dbdata["facebook"]["work"] == "":

                        dataFromLinked = self.searchFor(first_name,last_name,"",studies);
                        Quora = [];

                        if len(dataFromLinked) == 0:
                            arrayFromQuora = quora.searchQuora(first_name,middle_name,last_name,work,studies,locations);
                            if len(arrayFromQuora) != 0:
                                for i in arrayFromQuora:
                                    Quora.append(i);

                        else:
                            for dt in dataFromLinked:
                                if len(dt["Companies"]) == 0:
                                    work = "";
                                else:
                                    work = str.lower(str(dt["Companies"][0]));

                                if len(dt["Studies"]) == 0:
                                    studies = str.lower(str(dbdata["facebook"]["school"]));
                                else:
                                    studies = str.lower(str(dt["Studies"][0]));

                                if len(dt["locations"]) == 0:
                                    locations = str.lower(str(dbdata["facebook"]["city"]));
                                else:
                                    locations = str.lower(str(dt["locations"][0]).split(",")[0]);

                                arrayFromQuora = quora.searchQuora(first_name,middle_name,last_name,work,studies,locations);
                                #arrayFromQuora.append(dt["linkedInID"]);
                                print(arrayFromQuora);
                                if len(arrayFromQuora) != 0:
                                    for i in arrayFromQuora:
                                        Quora.append(i);

                        self.db.Records.update({"Number":data[0]},{'$set':{"linkedin":dataFromLinked,"Quora":Quora}});
                        glassDoor.put({"Email":data[2],"Number":data[0]});
                        if len(Quora) != 0:
                            addToQueue = {"email":data[2],"number":data[0],"Link":Quora};
                            qoQueue.put(addToQueue);
            except Exception as e:
                pass;

            # elif lnQueue.qsize() == 0 and flag == 0:
            #     time.sleep(40);
            #     flag = 1;




            #qLinked.get()[2]

# ln = LinkedIn();
# ln.searchFor("Arun","Gupta","anirudh_murali@ymail.com","7066918164","","Army Institute of Technology");
#print quora.searchQuora("Rohan","","Chougule","","Army Institute of Technology","Pune");
