import pandas as pd
from pandas import isnull

def lets_clean(input_file):
	input_ = pd.read_csv(input_file,header = -1,dtype = str,names = list('abcd'),skipinitialspace = True,skip_blank_lines = True)
	# print input_
	null_array = isnull(input_)# input_.fillna('none')
	# print null_array
	for i in range(0,input_.shape[0]):
		if str(null_array.iloc[i,3])!='True':
		    if str(null_array.iloc[i,2]) == 'False':
		        input_.iloc[i,1] = str(input_.iloc[i,1]) + str(input_.iloc[i,2])
		    input_.iloc[i,2] = input_.iloc[i,3]
		    input_.iloc[i,3] = None
	input_ = input_.drop('d', axis=1,)
	return input_
