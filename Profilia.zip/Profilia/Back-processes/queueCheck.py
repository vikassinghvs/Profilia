from multiprocessing import Queue
from multiprocessing import Process
from collections import deque

def fun1():
    a =  Queue();
    a.put("a");
    a.put("b");
    a.put("c");
    fun2(a);
    fun3(a);



def fun2(a):
    print(a.get());
    a.put("jkdfs");

def fun3(a):
    print(a.get());
    print(a.get());
    print(a.get());
