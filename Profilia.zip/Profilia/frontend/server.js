var express = require('express');
var cors = require('cors');
var app = express();
var bodyParser= require('body-parser');
app.use(cors());
app.use(bodyParser.json());

var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');

var url='mongodb://localhost:27017/Mahindra';
var response_value;

app.post('/find_profile',function(req,res){

  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var query = { Email: req.body.email_value_back };
    db.collection("Records").find(query).toArray(function(err, result) {
      if (err) throw err;
      db.close();
        if(result.length==0)
        {
          res.send({val:"1"});
          console.log("no results found");
        }
        else {
          console.log(result);
          res.send({val:result});
        }
      });
  });


});

app.get('/check',function(req,res){
  res.send('hello');
})

app.listen(3001);
