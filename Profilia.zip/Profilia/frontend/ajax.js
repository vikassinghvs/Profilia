
var regex_value_for_email_value= /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/


function email_function_for_to_find(){

  var email_input = $("#email_value_from_frontend").val();

  if(email_input!="" && email_input!=" ")
  {

    $(".preloader-wrapper").addClass("active");
    $(".btn").addClass("disabled");

    var main_data = {"email_value_back":email_input};

    $.ajax({
        type: 'POST',
        crossOrigin:true,
        data: JSON.stringify(main_data),
            contentType: 'application/json',
                    url: 'http://192.168.43.120:3001/find_profile',
                    success: function(data) {

                      $(".preloader-wrapper").removeClass("active");
                      $(".btn").removeClass("disabled");

                      console.log(data.val);

                      if(data.val=="1")
                      {
                        console.log("asdfsaf");
                        $("#modal1").children().children().children().text("");
                        $("#modal1").children().children().children().html("<br>Sorry we couldn't find <b> "+email_input+' </b> in out databases');
                        $('#modal1').modal('open');
                      }
                      else {
                          // first_serach_whether_its_company_or_person

                          all_the_keys_of_data = Object.keys(data.val[0])

                          if(all_the_keys_of_data.indexOf('Type')!=-1)
                          {
                            //  $("#screen_to_find_people").css('display','none');
                            //  $("#company_profile_link").css('display','block');


                            try{
                              $(".enter_name_company_description_web_urls").append('<div class="col s12 company_name" style="font-size:2.0vw;"></div>')
                              $(".company_name").html(data.val[0].Name);
                            }
                            catch(err)
                            {
                                console.log(err);
                            }



                             all_keys_of_google_data= Object.keys(data.val[0].GoogleData)

                             try{


                                  if( all_keys_of_google_data.indexOf("Type")!=-1 )
                                  {

                                    $(".enter_name_company_description_web_urls").append('<div class="col s12 company_descirption_small" ></div>')
                                    $('.company_descirption_small').html(data.val[0].GoogleData.Type+'<br> <br>');

                                  }

                                  if(all_keys_of_google_data.indexOf('Description')!=-1)
                                  {
                                    $(".enter_name_company_description_web_urls").append('<div class="col s12 main_description"></div>')
                                    $('.company_descirption_small').html(data.val[0].GoogleData.Description);

                                  }

                                 if(all_keys_of_google_data.indexOf('digital_footprint')!=-1)
                                 {
                                   $(".enter_name_company_description_web_urls").append('<div class="row"><div class="col s2"><img src="img/digital_foot.png" alt="" class="responsive-img"></div> <div class="col s10 furhter_web_urls"> </div></div> ')

                                   var sample_data="<br>";

                                   for(var i=0;i<data.val[0].GoogleData.digital_footprint.length/2;i++)
                                   {
                                       first_index = data.val[0].GoogleData.digital_footprint[i].indexOf('//');
                                       second_indices_of_slash = data.val[0].GoogleData.digital_footprint[i].indexOf('/',first_index+2);
                                       final_handle_value= data.val[0].GoogleData.digital_footprint[i].substring(first_index+2,second_indices_of_slash);
                                       sample_data=sample_data+'<a href=" '+data.val[0].GoogleData.digital_footprint[i]+' " target=_blank> ' + final_handle_value+' </a> <br> '
                                   }

                                   $(".furhter_web_urls").html(sample_data);
                                 }


                                  if( all_keys_of_google_data.indexOf("direction")!=-1)
                                  {
                                    $(".company_dircetion_address_weblink_contact_info").append('<div class="col s12 dircetion_in_google_map"><div class="col s2"> <br><img src="img/go_loca.png" alt="" class="responsive-img"> <!-- notice the "circle" class --></div><div class="col s10 direction_value_put_here"> <br> <br></div></div>')
                                    $('.direction_value_put_here').html('<br> <br> <a href="'  +data.val[0].GoogleData.direction+' " target=_blank> Google Maps Direction </a>' );
                                  }

                                  if( all_keys_of_google_data.indexOf("Address")!=-1)
                                  {
                                    $(".company_dircetion_address_weblink_contact_info").append('<div class="col s12 address_of_the_company"> <div class="col s2"> <br> <img src="img/busiadd.png" alt="" class="responsive-img"> </div> <div class="col s10 address_field_value_put_here"> </div> </div>')
                                    $(".address_field_value_put_here").html('<br>'+data.val[0].GoogleData.Address)
                                  }

                                  if(all_keys_of_google_data.indexOf("website")!=-1)
                                  {
                                       $(".company_dircetion_address_weblink_contact_info").append('<div class="col s12 weblink_of_the_company"><div class="col s2"> <br><img src="img/web_link.png" alt="" class="responsive-img"> <!-- notice the "circle" class --></div><div class="col s10 web_link_value_put_here"></div></div>')
                                       $(".web_link_value_put_here").html('<br> <a href="'+data.val[0].GoogleData.website+'" target=_blank> Visit the website </a>')
                                  }

                                  if(all_keys_of_google_data.indexOf("Phone")!=-1)
                                  {
                                     $(".company_dircetion_address_weblink_contact_info").append('<div class="col s12 contact_info"><div class="col s2"> <br><img src="img/phone.png" alt="" class="responsive-img"> <!-- notice the "circle" class --></div><div class="col s10 contact_value_put_here"></div></div>')
                                     $(".contact_value_put_here").html('<br>'+data.val[0].GoogleData.Phone)
                                  }

                                  if(all_keys_of_google_data.indexOf("mouthshut")!=-1)
                                  {
                                     if(jQuery.isEmptyObject(data.val[0].GoogleData.mouthshut)!=true)
                                     {

                                        $('.mouthshut_link').html('<br> <div class="row"><div class="col s1"><img src="img/web_link.png" alt="" class="responsive-img"></div> <div class="col s10"> <br> <a href=" '+ data.val[0].GoogleData.mouthshutLink+ ' " target=_blank> Visit MouthShut Link</a></div> </div>');

                                        var sample_value='<div class="col s1"> <img src="/img/facebook_reviews.png" alt="" class="responsive-img"> </div> <div class="col s10">'

                                        try{

                                          for(var i=0;i<data.val[0].GoogleData.mouthshut.Reviews.length;i++)
                                          {
                                             sample_value= sample_value+data.val[0].GoogleData.mouthshut.Reviews[i]+'<br>';
                                          }

                                          if(data.val[0].GoogleData.mouthshut.Reviews.length!=0)
                                          {
                                            $('.mouth_reviews').html(sample_value+'</div>');

                                          }
                                        }catch(err)
                                        {
                                          console.log(err);
                                        }


                                        try{

                                          if(data.val[0].GoogleData.mouthshut.Contact!="")
                                          {
                                            $('.mouth_contact').html('<br> <div class="col s1"> <img src="/img/phone.png" alt="" class="responsive-img"> </div> <div class="col s10">'+data.val[0].GoogleData.mouthshut.Contact+'</div>')
                                          }

                                        }catch(err)
                                        {
                                          console.log(err);
                                        }

                                        try{

                                          if(data.val[0].GoogleData.mouthshut.Location!="")
                                          {
                                            $('.mouth_location').html('<br> <div class="col s1"> <img src="/img/loca.png" alt="" class="responsive-img"> </div> <div class="col s10">'+data.val[0].GoogleData.mouthshut.Location+'</div>')
                                          }

                                        }catch(err)
                                        {
                                          console.log(err);
                                        }


                                        try{

                                            var sample_value="";

                                             for(var i=0;i<data.val[0].GoogleData.mouthshut.Sentiment.length;i++)
                                             {
                                                 sample_value=sample_value+data.val[0].GoogleData.mouthshut.Sentiment[i]+'<br>'
                                             }
                                        }catch(err){

                                          console.log(err);
                                        }

                                        try{

                                          if(data.val[0].GoogleData.mouthshut.Sentiment.length!=0)
                                          {
                                            $('.mouth_sentiment').html(sample_value);
                                          }

                                        }catch(err){

                                          console.log(err);
                                        }


                                        try{
                                          if(data.val[0].GoogleData.mouthshut.Tags!="")
                                          {
                                            $('.mouth_Tags').html('<br> <div class="col s1"> <img src="/img/mahidra_tag.png" alt="" class="responsive-img"> </div> <div class="col s10">'+data.val[0].GoogleData.mouthshut.Tags+'</div>');

                                          }

                                        }catch(err)
                                        {
                                          console.log(err);
                                        }



                                     }
                                  }
                             }
                             catch(err)
                             {
                               console.log(err);
                             }


                          }


                            console.log(Object.keys(data.val[0]))
                            $("#screen_for_profile").css('display','block');
                            $("#screen_to_find_people").css('display','none');
                            $("#email_value_from_frontend").val("");

                            // enter facebook wala details

                            if(all_the_keys_of_data.indexOf('Type')!=-1)
                            {
                              $("#company_if_present_link").html('<b> Company </b> : <a  onclick="view_company()" href="#!" > Visit the Organisation/Educational Institute </a>')
                            }


                            try{
                              $("#profile_email_id").html("<b> Email - </b>"+data.val[0].Email)
                              $("#profile_number").html("<b> Number - </b>"+data.val[0].Number)
                            }
                            catch(err){
                                console.log(err);
                            }

                            if(all_the_keys_of_data.indexOf('facebook')!=-1)
                            {

                              try{
                                $("#name_of_the_person_facebook").text(data.val[0].facebook.first_name+" "+data.val[0].facebook.middle_name+ " " +data.val[0].facebook.last_name)
                              }catch(err)
                              {
                                  console.log(err);
                              }

                              try{
                                $("#what_he_does_currently_facebook").text(data.val[0].facebook.work)
                              }
                              catch(err){
                                console.log(err);
                              }

                              try{
                                $("#where_he_lives_currently_facebook").text(data.val[0].facebook.city)
                              }
                              catch(err){
                                console.log(err);
                              }

                              try{
                                $("#where_he_studied").text(data.val[0].facebook.school)
                              }
                              catch(err){
                                  console.log(err);
                              }

                              try{
                                $("#position_of_the_persion").text(data.val[0].facebook.position)
                              }
                              catch(err){
                                  console.log(err);
                              }

                              try{
                                $("#profile_link_facebook").html('<b>Visit Facebook profile :</b> <a href="' +data.val[0].facebook.ProfileLink+'" target="_blank">'+data.val[0].facebook.first_name+" "+data.val[0].facebook.middle_name+ " " +data.val[0].facebook.last_name +'</a> <br> <br>')
                              }
                              catch(err)
                              {
                                  console.log(err);
                              }
                            }
                            else {

                                if(all_the_keys_of_data.indexOf('Type')!=-1)
                                {

                                  $("#name_of_the_person_facebook").html('<b> Company </b> : <a  onclick="view_company()" href="#!" > Visit the Company </a>')
                                }else {

                                  $("#name_of_the_person_facebook").text("No results found on Facebok");
                                }
                            }


                            if(all_the_keys_of_data.indexOf('facebook')!=-1)
                            {

                              var number_of_keys_in_facebook_extended={};

                              try{
                                var number_of_keys_in_facebook_extended=Object.keys(data.val[0].facebookInfo)

                              }catch(err)
                              {
                                  console.log(err);
                              }

                              try{

                                  try{

                                    if(number_of_keys_in_facebook_extended.indexOf('tv')!=-1)
                                    {
                                      if(data.val[0].facebookInfo.tv.length!=0)
                                      {
                                        $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_tv"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/facebook_tv.png" alt="" class="responsive-img"> </div> <div class="col s9 facebook_tv_value"> <br> <br> </div> </div> </div>')

                                        var sample_array_value="<br><b><h5> Television Shows </h5></b>";

                                        for(var i=0;i<data.val[0].facebookInfo.tv.length;i++)
                                        {
                                            sample_array_value=sample_array_value+data.val[0].facebookInfo.tv[i]+'<br>'
                                        }

                                          $('.facebook_tv_value').html(sample_array_value);

                                      }
                                    }

                                  }catch(err)
                                  {
                                    console.log(err);

                                  }

                                  try{

                                    if(number_of_keys_in_facebook_extended.indexOf('education')!=-1)
                                    {

                                      if(data.val[0].facebookInfo.education.length!=0)
                                      {
                                        $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_education"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/facebook_study.png" alt="" class="responsive-img"> </div> <div class="col s9 facebook_education_value"> <br> <br> </div> </div> </div>')

                                        var sample_array_value="<br><b><h5> Education </h5></b>";

                                        for(var i=0;i<data.val[0].facebookInfo.education.length;i++)
                                        {
                                            sample_array_value=sample_array_value+data.val[0].facebookInfo.education[i]+'<br>'
                                        }

                                          $('.facebook_education_value').html(sample_array_value);

                                      }


                                    }
                                  }catch(err)
                                  {
                                    console.log(err);
                                  }

                              }catch(err)
                              {
                                console.log(err);
                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('bio')!=-1)
                                {
                                    if(data.val[0].facebookInfo.bio.length!=0)
                                    {
                                      $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_bio"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/facebook_bio.png" alt="" class="responsive-img"> </div> <div class="col s9 facebook_bio_value"> <br> <br> </div> </div> </div>')

                                      var sample_array_value="<br><b><h5> Bio-Data </h5></b>";

                                      for(var i=0;i<data.val[0].facebookInfo.bio.length;i++)
                                      {
                                          sample_array_value=sample_array_value+data.val[0].facebookInfo.bio[i]+'<br>'
                                      }

                                        $('.facebook_bio_value').html(sample_array_value);

                                    }

                                }

                              }catch(err){

                                console.log(err);

                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('overview')!=-1)
                                {
                                    if(data.val[0].facebookInfo.overview.length!=0)
                                    {
                                      $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_overview"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/facebook_overview.png" alt="" class="responsive-img"></div> <div class="col s9 facebook_overview_value"> <br> <br> </div> </div> </div>')

                                      var sample_array_value="<br><b><h5> Overview </h5></b>";

                                      for(var i=0;i<data.val[0].facebookInfo.overview.length;i++)
                                      {
                                          sample_array_value=sample_array_value+data.val[0].facebookInfo.overview[i]+'<br>'
                                      }

                                        $('.facebook_overview_value').html(sample_array_value);

                                    }

                                }

                              }catch(err){

                                console.log(err);

                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('living')!=-1)
                                {
                                    if(data.val[0].facebookInfo.living.length!=0)
                                    {
                                      $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_living"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/facebook_location.png" alt="" class="responsive-img"> </div> <div class="col s9 facebook_location_value"> <br> <br> </div> </div> </div>')

                                      var sample_array_value="<br><b><h5> Living </h5></b>";


                                      for(var i=0;i<data.val[0].facebookInfo.living.length;i++)
                                      {
                                          sample_array_value=sample_array_value+data.val[0].facebookInfo.living[i]+'<br>'
                                      }

                                        $('.facebook_location_value').html(sample_array_value);

                                    }
                                }


                              }catch(err)
                              {
                                  console.log(err);

                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('contact_info')!=-1)
                                {
                                    if(data.val[0].facebookInfo.contact_info.length!=0)
                                    {
                                      $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_contact_info"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/phone.png" alt="" class="responsive-img">  </div> <div class="col s9 facebook_phone_value"> <br> <br> </div> </div> </div>')

                                      var sample_array_value="<br><b><h5> General Information </h5></b>";


                                      for(var i=0;i<data.val[0].facebookInfo.contact_info.length;i++)
                                      {
                                          sample_array_value=sample_array_value+data.val[0].facebookInfo.contact_info[i]+'<br>'
                                      }

                                        $('.facebook_phone_value').html(sample_array_value);

                                    }


                                }


                              }catch(err){
                                console.log(err);
                              }



                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('relationship')!=-1)
                                {
                                     if(data.val[0].facebookInfo.relationship.length!=0)
                                     {
                                       $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_relationship"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/facebook_relationship.png" alt="" class="responsive-img"></div> <div class="col s9 facebook_relationship_value"> <br><br> </div> </div> </div>')

                                       var sample_array_value="<br><b><h5> Relationship </h5></b>";

                                       for(var i=0;i<data.val[0].facebookInfo.relationship.length;i++)
                                       {
                                           sample_array_value=sample_array_value+data.val[0].facebookInfo.relationship[i]+'<br>'
                                       }

                                         $('.facebook_relationship_value').html(sample_array_value);

                                     }
                              }

                              }catch(err)
                              {
                                console.log(err);
                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('year_overviews')!=-1)
                                {
                                    if(data.val[0].facebookInfo.year_overviews.length!=0)
                                    {
                                      $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_year_overviews"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/facebook_yearly_overview.png" alt="" class="responsive-img"> </div> <div class="col s9 facebook_year_overviews_value"> <br><br> </div> </div> </div>')

                                      var sample_array_value="<br><b><h5> Years Overview </h5></b>";

                                      for(var i=0;i<data.val[0].facebookInfo.year_overviews.length;i++)
                                      {
                                          sample_array_value=sample_array_value+data.val[0].facebookInfo.year_overviews[i]+'<br>'
                                      }

                                        $('.facebook_year_overviews_value').html(sample_array_value);

                                    }
                                }


                              }catch(err){

                                  console.log(err);
                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('map')!=-1)
                                {
                                    if(data.val[0].facebookInfo.map.length!=0)
                                    {
                                      $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_map"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/facebook_checkins.png" alt="" class="responsive-img"> <!-- notice the "circle" class --> </div> <div class="col s9 facebook_map_value"> <br> <br> </div> </div> </div>')

                                      var sample_array_value="<br><b><h5> Places Visited </h5></b>";

                                      for(var i=0;i<data.val[0].facebookInfo.map.length;i++)
                                      {
                                          sample_array_value=sample_array_value+data.val[0].facebookInfo.map[i]+'<br>'
                                      }

                                      $('.facebook_map_value').html(sample_array_value);

                                    }

                                }


                              }catch(err){

                                console.log(err);

                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('sports')!=-1)
                                {
                                    if(data.val[0].facebookInfo.sports.length!=0)
                                    {
                                      $('.facebook_extended_actual').append('<div class="col s12"><div class="row facebook_sports"><div class="col s2 offset-s1"> <br> <br><img src="/img/sports.png" alt="" class="responsive-img"> <!-- notice the "circle" class --></div><div class="col s9 facebook_sports_value"> <br> <br></div></div></div>')

                                      var sample_array_value="<br><b><h5> Sports </h5></b>";

                                      for(var i=0;i<data.val[0].facebookInfo.sports.length;i++)
                                      {
                                          sample_array_value=sample_array_value+data.val[0].facebookInfo.sports[i]+'<br>'
                                      }

                                      $('.facebook_sports_value').html(sample_array_value);

                                    }

                                }

                              }catch(err){

                                console.log(err);
                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('likes')!=-1)
                                {
                                    if(data.val[0].facebookInfo.likes.length!=0)
                                    {
                                      $('.facebook_extended_actual').append('<div class="col s12"><div class="row facebook_likes"><div class="col s2 offset-s1"> <br> <br><img src="/img/face_book_likes.png" alt="" class="responsive-img"> <!-- notice the "circle" class --></div><div class="col s9 facebook_likes_value"> <br> <br></div></div></div>')

                                      var sample_array_value="<br><b><h5> Facebook Likes </h5></b>";

                                      for(var i=0;i<data.val[0].facebookInfo.likes.length;i++)
                                      {
                                          sample_array_value=sample_array_value+data.val[0].facebookInfo.likes[i]+'<br>'
                                      }

                                      $('.facebook_likes_value').html(sample_array_value);
                                    }

                                }

                              }catch(err){

                                console.log(err);

                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('games')!=-1)
                                {

                                  if(data.val[0].facebookInfo.games.length!=0)
                                  {

                                    $('.facebook_extended_actual').append('<div class="col s12"><div class="row facebook_games"><div class="col s2 offset-s1"> <br> <br><img src="/img/sports.png" alt="" class="responsive-img"> <!-- notice the "circle" class --></div><div class="col s9 facebook_games_value"> <br> <br></div></div></div>')

                                    var sample_array_value="<br><b><h5> Games </h5></b>";

                                    for(var i=0;i<data.val[0].facebookInfo.games.length;i++)
                                    {
                                        sample_array_value=sample_array_value+data.val[0].facebookInfo.games[i]+'<br>'
                                    }

                                    $('.facebook_games_value').html(sample_array_value);

                                  }


                                }
                              }catch(err){

                                console.log(err);

                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('events')!=-1)
                                {

                                  if(data.val[0].facebookInfo.events.length!=0)
                                  {

                                    $('.facebook_extended_actual').append('<div class="col s12"><div class="row facebook_events"><div class="col s2 offset-s1"> <br> <br><img src="/img/facebook_events.png" alt="" class="responsive-img"> <!-- notice the "circle" class --></div><div class="col s9 facebook_events_value"> <br><br></div></div></div>')

                                    var sample_array_value="<br><b><h5> Interested Events</h5></b>";

                                    for(var i=0;i<data.val[0].facebookInfo.events.length;i++)
                                    {
                                        sample_array_value=sample_array_value+data.val[0].facebookInfo.events[i]+'<br>'
                                    }

                                    $('.facebook_events_value').html(sample_array_value);

                                  }

                                }

                              }catch(err){

                                  console.log(err);
                              }


                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('groups')!=-1)
                                {

                                  if(data.val[0].facebookInfo.groups.length!=0)
                                  {

                                    $('.facebook_extended_actual').append('<div class="col s12"> <div class="row facebook_groups"> <div class="col s2 offset-s1"> <br> <br> <img src="/img/facebook_groups.png" alt="" class="responsive-img"> <!-- notice the "circle" class --> </div> <div class="col s9 facebook_groups_values"> <br> <br> </div> </div> </div>')

                                    var sample_array_value="<br><b><h5> Interested Events</h5></b>";


                                    for(var i=0;i<data.val[0].facebookInfo.groups.length;i++)
                                    {
                                        sample_array_value=sample_array_value+data.val[0].facebookInfo.groups[i]+'<br>'
                                    }

                                    $('.facebook_groups_values').html(sample_array_value);

                                  }
                                }

                              }catch(err){

                                console.log(err);

                              }

                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('books')!=-1)
                                {

                                  if(data.val[0].facebookInfo.books.length!=0)
                                  {
                                    $('.facebook_extended_actual').append('<div class="col s12"><div class="row facebook_books"><div class="col s2 offset-s1"> <br> <br><img src="/img/facebook_book.png" alt="" class="responsive-img"> <!-- notice the "circle" class --></div><div class="col s9 facebook_books_values"> <br> <br></div></div></div>')

                                    var sample_array_value="<br><b><h5> Books </h5></b>";

                                    for(var i=0;i<data.val[0].facebookInfo.books.length;i++)
                                    {
                                        sample_array_value=sample_array_value+data.val[0].facebookInfo.books[i]+'<br>'
                                    }

                                    $('.facebook_books_values').html(sample_array_value);
                                  }


                                }


                              }catch(err){

                                console.log(err);
                              }


                              try{

                                if(number_of_keys_in_facebook_extended.indexOf('reviews')!=-1)
                                {

                                    if(data.val[0].facebookInfo.reviews.length!=0)
                                    {
                                      $('.facebook_extended_actual').append('<div class="col s12"><div class="row facebook_reviews"><div class="col s2 offset-s1"> <br> <br><img src="/img/facebook_reviews.png" alt="" class="responsive-img"> <!-- notice the "circle" class --></div><div class="col s9 facebook_reviews_values"> <br> <br></div></div></div>')

                                      var sample_array_value="<br><b><h5> Reviewed </h5></b>";

                                      for(var i=0;i<data.val[0].facebookInfo.reviews.length;i++)
                                      {
                                          sample_array_value=sample_array_value+data.val[0].facebookInfo.reviews[i]+'<br>'
                                      }

                                      $('.facebook_reviews_values').html(sample_array_value);
                                    }

                                }


                              }catch(err){

                                console.log(err);
                              }

                            }
                            else {
                                $('.facebook_extended_actual').html('<div class="row"><div class="col s8 center">No profile found</div></div>');
                            }


                            // enter facebook_extended details
                            try{
                              $(".number_of_matched_found_for_linkedin").text('Number of matched results  '+data.val[0].linkedin.length);

                            }catch(err){

                              console.log(err);
                            }


                            try{

                              if(all_the_keys_of_data.indexOf('linkedin')!=-1)
                              {
                                if(data.val[0].linkedin.length!=0)
                                {

                                        try{

                                          for( var i=0;i<data.val[0].linkedin.length;i++)
                                          {
                                            $('.linked_in_box').append('<div class="row"> <div class="col s12 center linked_in_id_handle_name" style="font-size:1.4vw;"> </div> <div class="col s12 center headline_linked_in"> </div> <div class="col s12 center visit_his_profile"> </div> <div class="col s12"> <div class="row"> <br> <br> <div class="col s1 offset-s1"> <img src="/img/manu.png" alt="" class="responsive-img"> </div> <div class="col s10"> <div class="row company_details_one_by_one_linked_in"> </div> </div> </div> </div> <div class="col s12"> <div class="row"> <br> <br> <div class="col s1 offset-s1"> <img src="/img/university.png" alt="" class="responsive-img"> </div> <div class="col s10"> <div class="row studied_places_linked_in "> </div> </div> </div> </div> <div class="col s12"> <div class="row"> <br> <br> <div class="col s1 offset-s1"> <img src="/img/loca.png" alt="" class="responsive-img"> </div> <div class="col s10"> <div class="row location_one_by_one_linked_in"> </div> </div> </div> </div> </div>')
                                          }

                                        }catch(err){

                                          console.log(err);
                                        }

                                        try{

                                          for(var i=0;i<data.val[0].linkedin.length;i++)
                                          {
                                            for(var j=0;j<data.val[0].linkedin[i].Companies.length;j++)
                                            {
                                              $('.company_details_one_by_one_linked_in').eq(i).append('<div class="col s12"> </div>')
                                            }

                                            for(var j=0;j<data.val[0].linkedin[i].Studies.length;j++)
                                            {
                                              $('.studied_places_linked_in').eq(i).append('<div class="col s12"> </div>')
                                            }

                                            for(var j=0;j<data.val[0].linkedin[i].locations.length;j++)
                                            {
                                              $('.location_one_by_one_linked_in').eq(i).append('<div class="col s12"> </div>')
                                            }
                                          }


                                        }catch(err){

                                          console.log(err);
                                        }


                                        try{

                                          for(var i=0;i<data.val[0].linkedin.length;i++)
                                          {
                                            $('.headline_linked_in').eq(i).html(data.val[0].linkedin[i].headline_data)
                                            $('.linked_in_id_handle_name').eq(i).html('<b>Linked Profile Id </b>'+data.val[0].linkedin[i].linkedInID)
                                            $('.visit_his_profile').eq(i).html('Visit LinkedIn profile : <a href="https://www.linkedin.com/in/'+data.val[0].linkedin[i].linkedInID+'/" target="_blank">'+data.val[0].Name)
                                          }


                                        }catch(err)
                                        {

                                          console.log(err);
                                        }

                                        try{

                                          for(var i=0;i<data.val[0].linkedin.length;i++)
                                          {
                                            try{
                                              if(data.val[0].linkedin[i].Companies.length==0)
                                              {
                                                $('.company_details_one_by_one_linked_in').eq(i).append('<div class="col s12"> </div>');
                                                $('.company_details_one_by_one_linked_in').eq(i).children().eq(0).text('No companies found');
                                              }
                                            }catch(err){

                                              console.log(err);
                                            }

                                            try{

                                              for(var j=0;j<data.val[0].linkedin[i].Companies.length;j++)
                                              {
                                                $('.company_details_one_by_one_linked_in').eq(i).children().eq(j).text(data.val[0].linkedin[i].Companies[j])
                                              }

                                            }catch(err){
                                              console.log(err);

                                            }

                                            try{

                                              if(data.val[0].linkedin[i].Studies.length==0)
                                              {
                                                $('.company_details_one_by_one_linked_in').eq(i).children().eq(j).text('No Education details found');
                                              }

                                              for(var j=0;j<data.val[0].linkedin[i].Studies.length;j++)
                                              {
                                                $('.studied_places_linked_in').eq(i).children().eq(j).text(data.val[0].linkedin[i].Studies[j])
                                              }


                                            }catch(err){

                                                console.log(err);
                                            }

                                            try{

                                                  if(data.val[0].linkedin[i].locations.length==0)
                                                  {
                                                    $('.location_one_by_one_linked_in').eq(i).children().eq(j).text("No locations found")
                                                  }

                                                  for(var j=0;j<data.val[0].linkedin[i].locations.length;j++)
                                                  {
                                                    $('.location_one_by_one_linked_in').eq(i).children().eq(j).text(data.val[0].linkedin[i].locations[j])
                                                  }


                                            }catch(err){

                                              console.log(err);
                                            }

                                          }
                                        }catch(err){
                                          console.log(err);
                                      }
                                }
                                else {
                                  $(".number_of_matched_found_for_linkedin").text('No profiles found');
                                }
                              }
                              else{
                                $(".number_of_matched_found_for_linkedin").text('No profiles found');
                              }

                            }
                            catch(err){

                              console.log(err);
                            }



                            // now linked in details fill


                          try{

                            if(all_the_keys_of_data.indexOf('Quora').length!=-1)
                            {

                              $(".number_of_matches_found_for_quora").html("Number of Matches found : "+data.val[0].Quora.length)

                              for(var i=0;i<data.val[0].Quora.length;i++)
                              {
                                $(".quora_hits").append('<div class="row"> <div class="col s12 center quoara_handle_name" style="font-size:1.4vw;"> </div> <div class="col s12 center visit_quoara_of_the_person" style="font-size:1.3vw;"> </div> <div class="col s12 description_box"> <div class="row"> <br> <br> <div class="col s1 offset-s1"> <img src="/img/desc.png" alt="" class="responsive-img"> <!-- notice the "circle" class --> </div> <div class="col s10"> <div class="row actual_description"> </div> </div> </div> </div> <div class="col s12 his_interests_box"> <div class="row"> <br> <br> <div class="col s1 offset-s1"> <img src="/img/like.png" alt="" class="responsive-img"> </div> <div class="col s10"> <div class="row his_interests_actual_value"> </div> </div> </div> </div> <div class="col s12 question_and_answer_box"> <div class="row"> <br> <br> <div class="col s1 offset-s1"> <img src="/img/qa.png" alt="" class="responsive-img"> </div> <div class="col s10"> <div class="row"> <div class="col s12" style="font-size:1.8vw;"> Q/A related to Mahindra & Mahidra <br> <br> </div> <div class="row actual_question_with_answer"> </div> </div> </div> </div> </div> </div>')
                              }

                            }
                            else{
                              $(".number_of_matches_found_for_quora").html("Number of Matches found : 0")
                            }

                          }catch(err){

                            console.log(err);
                          }

                          try{

                                for(var i=0;i<data.val[0].Quora.length;i++)
                                {
                                    for(var j=0;j<data.val[0].QuoraAnalysis[i].questions.length;j++)
                                    {
                                      $(".actual_question_with_answer").eq(i).append('<div class="col s12"> </div> <div class="col s12"> </div>')
                                    }
                                }

                          }catch(err)
                          {
                            console.log(err);
                          }

                          try{
                            for(var i=0;i<data.val[0].Quora.length;i++)
                            {
                              for(var j=0;j<(data.val[0].QuoraAnalysis[i].topics.length/2)+1;j++)
                              {
                                $(".his_interests_actual_value").eq(i).append('<div class="col s6"></div>')
                                $(".his_interests_actual_value").eq(i).append('<div class="col s6"></div> ')

                              }
                            }

                          }catch(err){

                            console.log(err);
                          }


                          try{

                            for(var i=0;i<data.val[0].Quora.length;i++)
                            {
                              var handle_link = data.val[0].QuoraAnalysis[i].Link;
                              last_inde_of_slash= handle_link.lastIndexOf('/');
                              var handle_name=handle_link.substring(last_inde_of_slash+1, handle_link.length);
                              $('.quoara_handle_name').eq(i).html('<b>Quora Profile Id</b> '+handle_name+'<br>'+
                                'Visit Quora Profile : <a href=" '+data.val[0].QuoraAnalysis[i].Link+' " target=_blank >'+data.val[0].Name+'</a>'
                              )
                            }
                          }catch(err){

                            console.log(err);
                          }

                          try{
                            for(var i=0;i<data.val[0].Quora.length;i++)
                            {
                              $(".actual_description").eq(i).html(
                                '<h5>Education</h5>'+
                                '<div class="col s12">'+data.val[0].QuoraAnalysis[i].credential[0]+'</div>'+
                                '<div class="col s12">'+data.val[0].QuoraAnalysis[i].credential[1]+' <br> </div> '+
                                '<div class="col s12"> <b> Basic Description : </b>'+data.val[0].QuoraAnalysis[i].description+'</div>'
                              )
                            }
                          }catch(err){
                            console.log(err);
                          }

                          try{
                                for(var i=0;i<data.val[0].Quora.length;i++)
                                {
                                  for(var j=0;j<data.val[0].QuoraAnalysis[i].topics.length;j=j+2)
                                  {
                                        $('.his_interests_actual_value').eq(i).children().eq(j).html(data.val[0].QuoraAnalysis[i].topics[j])
                                        $('.his_interests_actual_value').eq(i).children().eq(j+1).html(data.val[0].QuoraAnalysis[i].topics[j+1]+'<br>')
                                  }
                                }

                          }catch(err){

                            console.log(err);
                          }


                          try{

                            for(var i=0;i<data.val[0].Quora.length;i++)
                            {
                              for(var j=0;j<data.val[0].QuoraAnalysis[i].questions.length;j++)
                              {
                                  $('.actual_question_with_answer').eq(i).children().eq(j).html(
                                    'Que. '+data.val[0].QuoraAnalysis[i].questions[j]+'<br>'+
                                    'Ans. '+data.val[0].QuoraAnalysis[i].answers[j]+'<br>'
                                  )
                              }
                            }

                          }catch(err){
                            console.log(err);
                          }


                            // find the matches for quoara

                            try{

                              flag=0;
                              keys_array = Object.keys(data.val[0]);

                              for (var i=0;i<keys_array.length;i++)
                              {
                                if(keys_array[i]=="Glassdoor")
                                  {
                                      flag=1;
                                  }
                              }
                            }catch(err){

                              console.log(err)

                            }

                            try{

                              if(flag==1)
                              {
                                $(".glassdoorcompany_name").html()
                                $(".glassdoorindustry").html()
                                $(".glassdooroverallRating").html()
                                $(".glassdoorratingDescription").html()
                                $(".what_people_have_to_say").html()
                                $(".glassdoorheadline").html()
                                $(".glassdoorpros").html()
                                $(".glassdoorcons").html()


                              }else {

                                var_companies="";

                                $(".glassdoorcompany_name").html('Sorry No Results found')

                                try{

                                      for(var i=0;i<data.val[0].linkedin.length;i++)
                                      {
                                         for(var j=0;j<data.val[0].linkedin[i].Companies.length;j++)
                                         {
                                           var_companies=var_companies+data.val[0].linkedin[i].Companies[j]+'<br>'
                                         }
                                      }


                                }catch(err){

                                  console.log(err);

                                }


                                try{
                                  if(var_companies=="")
                                  {
                                    $(".glassdoorindustry").html('Sorry no companies are related to this profile !!!!! ');
                                  }
                                  else {
                                    var_companies=var_companies+data.val[0].facebook.work+'<br>'
                                    $(".glassdoorindustry").html('Tried Searching these Companies on Glassdoor <br> '+var_companies);
                                  }

                                }catch(err){

                                    console.log(err);
                                }

                              }

                            }catch(err){

                                console.log(err);
                            }



                            // viacom


                            // twitter

                            if(all_the_keys_of_data.indexOf('twitter')!=-1)
                            {
                              try{

                                $(".number_of_twitter_match_found").html('<br> Number of Matches found : '+data.val[0].twitter.length)

                                for(var i=0;i<data.val[0].twitter.length;i++)
                                {
                                    $('#twitter_profiles').append('<div class="col s5"> <div class="card " style="background-color:#4099FF;"> <div class="card-content white-text"> <a class="twitter-timeline" data-width="300" data-height="300" data-aria-polite="assertive" href="https://twitter.com/'+data.val[0].twitter[i].screen_name + '">Tweets by TwitterDev</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script> </div> </div> </div>')
                                }

                              }catch(err){

                                console.log(err);
                              }
                            }
                            else {
                              $(".number_of_twitter_match_found").html('<br> No match found ');
                            }


                      }

                   },
                    error: function(err){

                      $(".preloader-wrapper").removeClass("active");
                      $(".btn").removeClass("disabled");

                      $("#modal1").children().children().children().text("");

                      $("#modal1").children().children().children().html("<br>Server connection failed<br>");

                      $('#modal1').modal('open');

                        console.log(err)
                      }
          });
  }
  else {

      console.log("hello");

      $("#modal1").children().children().children().text("");

      if(email_input==""){
        $("#modal1").children().children().children().html("<br>Please enter email address <br>");
      }else
      {
        $("#modal1").children().children().children().html("<br>Please enter Correct email address <br>");
      }

      $('#modal1').modal('open');

    }
}
