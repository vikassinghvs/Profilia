

function go_back_button_person()
{


    $("#profile_email_id").empty()
    $("#profile_number").empty()
    $("#name_of_the_person_facebook").empty()
    $("#what_he_does_currently_facebook").empty()
    $("#where_he_lives_currently_facebook").empty()
    $("#where_he_studied").empty("")
    $("#position_of_the_persion").val("")
    $("#profile_link_facebook").empty()

    // linked in box removed all data removed

    $('.linked_in_box').empty();

    // quora data has to be removed

    $(".quora_hits").empty();
    $(".number_of_matches_found_for_quora").empty();

    // glassdoor data has to be removed;

    $(".glassdoorindustry").empty("");
    $(".glassdooroverallRating").empty("")
    $(".glassdoorratingDescription").empty("")
    $(".what_people_have_to_say").empty("")
    $(".glassdoorheadline").empty("")
    $(".glassdoorpros").empty("")
    $(".glassdoorcons").empty("")

    // twitte profiles empty

    $('#twitter_profiles').empty();

    // facebook_extended_empty

    $(".facebook_extended_actual").empty();

    $(".enter_name_company_description_web_urls").empty();
    $(".company_dircetion_address_weblink_contact_info").empty();

    // mouthshut khali karna hain

    $(".mouthshut_link").empty();
    $('.mouth_reviews').empty();
    $('.mouth_contact').empty();
    $('.mouth_location').empty();
    $('.mouth_sentiment').empty();
    $('.mouth_Tags').empty();
    $("#company_if_present_link").empty();

  $("#screen_for_profile").css('display','none');
  $("#screen_to_find_people").css('display','block');

  // removing the data of the old divs

}

function view_company()
{
  $("#screen_for_profile").css('display','none');
  $("#company_profile_link").css('display','block');

}

function go_back_button_profile()
{
    $("#screen_for_profile").css('display','block');
    $("#company_profile_link").css('display','none');
}
